(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

  function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common"], {
    /***/
    "./node_modules/@ionic/core/dist/esm/button-active-0d5784f9.js":
    /*!*********************************************************************!*\
      !*** ./node_modules/@ionic/core/dist/esm/button-active-0d5784f9.js ***!
      \*********************************************************************/

    /*! exports provided: c */

    /***/
    function node_modulesIonicCoreDistEsmButtonActive0d5784f9Js(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "c", function () {
        return createButtonActiveGesture;
      });
      /* harmony import */


      var _index_44bf8136_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./index-44bf8136.js */
      "./node_modules/@ionic/core/dist/esm/index-44bf8136.js");
      /* harmony import */


      var _index_eea61379_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index-eea61379.js */
      "./node_modules/@ionic/core/dist/esm/index-eea61379.js");
      /* harmony import */


      var _haptic_7b8ba70a_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./haptic-7b8ba70a.js */
      "./node_modules/@ionic/core/dist/esm/haptic-7b8ba70a.js");

      var createButtonActiveGesture = function createButtonActiveGesture(el, isButton) {
        var currentTouchedButton;
        var initialTouchedButton;

        var activateButtonAtPoint = function activateButtonAtPoint(x, y, hapticFeedbackFn) {
          if (typeof document === 'undefined') {
            return;
          }

          var target = document.elementFromPoint(x, y);

          if (!target || !isButton(target)) {
            clearActiveButton();
            return;
          }

          if (target !== currentTouchedButton) {
            clearActiveButton();
            setActiveButton(target, hapticFeedbackFn);
          }
        };

        var setActiveButton = function setActiveButton(button, hapticFeedbackFn) {
          currentTouchedButton = button;

          if (!initialTouchedButton) {
            initialTouchedButton = currentTouchedButton;
          }

          var buttonToModify = currentTouchedButton;
          Object(_index_44bf8136_js__WEBPACK_IMPORTED_MODULE_0__["c"])(function () {
            return buttonToModify.classList.add('ion-activated');
          });
          hapticFeedbackFn();
        };

        var clearActiveButton = function clearActiveButton() {
          var dispatchClick = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;

          if (!currentTouchedButton) {
            return;
          }

          var buttonToModify = currentTouchedButton;
          Object(_index_44bf8136_js__WEBPACK_IMPORTED_MODULE_0__["c"])(function () {
            return buttonToModify.classList.remove('ion-activated');
          });
          /**
           * Clicking on one button, but releasing on another button
           * does not dispatch a click event in browsers, so we
           * need to do it manually here. Some browsers will
           * dispatch a click if clicking on one button, dragging over
           * another button, and releasing on the original button. In that
           * case, we need to make sure we do not cause a double click there.
           */

          if (dispatchClick && initialTouchedButton !== currentTouchedButton) {
            currentTouchedButton.click();
          }

          currentTouchedButton = undefined;
        };

        return Object(_index_eea61379_js__WEBPACK_IMPORTED_MODULE_1__["createGesture"])({
          el: el,
          gestureName: 'buttonActiveDrag',
          threshold: 0,
          onStart: function onStart(ev) {
            return activateButtonAtPoint(ev.currentX, ev.currentY, _haptic_7b8ba70a_js__WEBPACK_IMPORTED_MODULE_2__["a"]);
          },
          onMove: function onMove(ev) {
            return activateButtonAtPoint(ev.currentX, ev.currentY, _haptic_7b8ba70a_js__WEBPACK_IMPORTED_MODULE_2__["b"]);
          },
          onEnd: function onEnd() {
            clearActiveButton(true);
            Object(_haptic_7b8ba70a_js__WEBPACK_IMPORTED_MODULE_2__["h"])();
            initialTouchedButton = undefined;
          }
        });
      };
      /***/

    },

    /***/
    "./node_modules/@ionic/core/dist/esm/framework-delegate-d1eb6504.js":
    /*!**************************************************************************!*\
      !*** ./node_modules/@ionic/core/dist/esm/framework-delegate-d1eb6504.js ***!
      \**************************************************************************/

    /*! exports provided: a, d */

    /***/
    function node_modulesIonicCoreDistEsmFrameworkDelegateD1eb6504Js(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "a", function () {
        return attachComponent;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "d", function () {
        return detachComponent;
      });

      var attachComponent = /*#__PURE__*/function () {
        var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(delegate, container, component, cssClasses, componentProps) {
          var el;
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  if (!delegate) {
                    _context.next = 2;
                    break;
                  }

                  return _context.abrupt("return", delegate.attachViewToDom(container, component, componentProps, cssClasses));

                case 2:
                  if (!(typeof component !== 'string' && !(component instanceof HTMLElement))) {
                    _context.next = 4;
                    break;
                  }

                  throw new Error('framework delegate is missing');

                case 4:
                  el = typeof component === 'string' ? container.ownerDocument && container.ownerDocument.createElement(component) : component;

                  if (cssClasses) {
                    cssClasses.forEach(function (c) {
                      return el.classList.add(c);
                    });
                  }

                  if (componentProps) {
                    Object.assign(el, componentProps);
                  }

                  container.appendChild(el);

                  if (!el.componentOnReady) {
                    _context.next = 11;
                    break;
                  }

                  _context.next = 11;
                  return el.componentOnReady();

                case 11:
                  return _context.abrupt("return", el);

                case 12:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee);
        }));

        return function attachComponent(_x, _x2, _x3, _x4, _x5) {
          return _ref.apply(this, arguments);
        };
      }();

      var detachComponent = function detachComponent(delegate, element) {
        if (element) {
          if (delegate) {
            var container = element.parentElement;
            return delegate.removeViewFromDom(container, element);
          }

          element.remove();
        }

        return Promise.resolve();
      };
      /***/

    },

    /***/
    "./node_modules/@ionic/core/dist/esm/haptic-7b8ba70a.js":
    /*!**************************************************************!*\
      !*** ./node_modules/@ionic/core/dist/esm/haptic-7b8ba70a.js ***!
      \**************************************************************/

    /*! exports provided: a, b, c, d, h */

    /***/
    function node_modulesIonicCoreDistEsmHaptic7b8ba70aJs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "a", function () {
        return hapticSelectionStart;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "b", function () {
        return hapticSelectionChanged;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "c", function () {
        return hapticSelection;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "d", function () {
        return hapticImpact;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "h", function () {
        return hapticSelectionEnd;
      });

      var HapticEngine = {
        getEngine: function getEngine() {
          var win = window;
          return win.TapticEngine || win.Capacitor && win.Capacitor.isPluginAvailable('Haptics') && win.Capacitor.Plugins.Haptics;
        },
        available: function available() {
          return !!this.getEngine();
        },
        isCordova: function isCordova() {
          return !!window.TapticEngine;
        },
        isCapacitor: function isCapacitor() {
          var win = window;
          return !!win.Capacitor;
        },
        impact: function impact(options) {
          var engine = this.getEngine();

          if (!engine) {
            return;
          }

          var style = this.isCapacitor() ? options.style.toUpperCase() : options.style;
          engine.impact({
            style: style
          });
        },
        notification: function notification(options) {
          var engine = this.getEngine();

          if (!engine) {
            return;
          }

          var style = this.isCapacitor() ? options.style.toUpperCase() : options.style;
          engine.notification({
            style: style
          });
        },
        selection: function selection() {
          this.impact({
            style: 'light'
          });
        },
        selectionStart: function selectionStart() {
          var engine = this.getEngine();

          if (!engine) {
            return;
          }

          if (this.isCapacitor()) {
            engine.selectionStart();
          } else {
            engine.gestureSelectionStart();
          }
        },
        selectionChanged: function selectionChanged() {
          var engine = this.getEngine();

          if (!engine) {
            return;
          }

          if (this.isCapacitor()) {
            engine.selectionChanged();
          } else {
            engine.gestureSelectionChanged();
          }
        },
        selectionEnd: function selectionEnd() {
          var engine = this.getEngine();

          if (!engine) {
            return;
          }

          if (this.isCapacitor()) {
            engine.selectionEnd();
          } else {
            engine.gestureSelectionEnd();
          }
        }
      };
      /**
       * Trigger a selection changed haptic event. Good for one-time events
       * (not for gestures)
       */

      var hapticSelection = function hapticSelection() {
        HapticEngine.selection();
      };
      /**
       * Tell the haptic engine that a gesture for a selection change is starting.
       */


      var hapticSelectionStart = function hapticSelectionStart() {
        HapticEngine.selectionStart();
      };
      /**
       * Tell the haptic engine that a selection changed during a gesture.
       */


      var hapticSelectionChanged = function hapticSelectionChanged() {
        HapticEngine.selectionChanged();
      };
      /**
       * Tell the haptic engine we are done with a gesture. This needs to be
       * called lest resources are not properly recycled.
       */


      var hapticSelectionEnd = function hapticSelectionEnd() {
        HapticEngine.selectionEnd();
      };
      /**
       * Use this to indicate success/failure/warning to the user.
       * options should be of the type `{ style: 'light' }` (or `medium`/`heavy`)
       */


      var hapticImpact = function hapticImpact(options) {
        HapticEngine.impact(options);
      };
      /***/

    },

    /***/
    "./node_modules/@ionic/core/dist/esm/spinner-configs-c78e170e.js":
    /*!***********************************************************************!*\
      !*** ./node_modules/@ionic/core/dist/esm/spinner-configs-c78e170e.js ***!
      \***********************************************************************/

    /*! exports provided: S */

    /***/
    function node_modulesIonicCoreDistEsmSpinnerConfigsC78e170eJs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "S", function () {
        return SPINNERS;
      });

      var spinners = {
        'bubbles': {
          dur: 1000,
          circles: 9,
          fn: function fn(dur, index, total) {
            var animationDelay = "".concat(dur * index / total - dur, "ms");
            var angle = 2 * Math.PI * index / total;
            return {
              r: 5,
              style: {
                'top': "".concat(9 * Math.sin(angle), "px"),
                'left': "".concat(9 * Math.cos(angle), "px"),
                'animation-delay': animationDelay
              }
            };
          }
        },
        'circles': {
          dur: 1000,
          circles: 8,
          fn: function fn(dur, index, total) {
            var step = index / total;
            var animationDelay = "".concat(dur * step - dur, "ms");
            var angle = 2 * Math.PI * step;
            return {
              r: 5,
              style: {
                'top': "".concat(9 * Math.sin(angle), "px"),
                'left': "".concat(9 * Math.cos(angle), "px"),
                'animation-delay': animationDelay
              }
            };
          }
        },
        'circular': {
          dur: 1400,
          elmDuration: true,
          circles: 1,
          fn: function fn() {
            return {
              r: 20,
              cx: 48,
              cy: 48,
              fill: 'none',
              viewBox: '24 24 48 48',
              transform: 'translate(0,0)',
              style: {}
            };
          }
        },
        'crescent': {
          dur: 750,
          circles: 1,
          fn: function fn() {
            return {
              r: 26,
              style: {}
            };
          }
        },
        'dots': {
          dur: 750,
          circles: 3,
          fn: function fn(_, index) {
            var animationDelay = -(110 * index) + 'ms';
            return {
              r: 6,
              style: {
                'left': "".concat(9 - 9 * index, "px"),
                'animation-delay': animationDelay
              }
            };
          }
        },
        'lines': {
          dur: 1000,
          lines: 12,
          fn: function fn(dur, index, total) {
            var transform = "rotate(".concat(30 * index + (index < 6 ? 180 : -180), "deg)");
            var animationDelay = "".concat(dur * index / total - dur, "ms");
            return {
              y1: 17,
              y2: 29,
              style: {
                'transform': transform,
                'animation-delay': animationDelay
              }
            };
          }
        },
        'lines-small': {
          dur: 1000,
          lines: 12,
          fn: function fn(dur, index, total) {
            var transform = "rotate(".concat(30 * index + (index < 6 ? 180 : -180), "deg)");
            var animationDelay = "".concat(dur * index / total - dur, "ms");
            return {
              y1: 12,
              y2: 20,
              style: {
                'transform': transform,
                'animation-delay': animationDelay
              }
            };
          }
        }
      };
      var SPINNERS = spinners;
      /***/
    },

    /***/
    "./node_modules/@ionic/core/dist/esm/theme-3f0b0c04.js":
    /*!*************************************************************!*\
      !*** ./node_modules/@ionic/core/dist/esm/theme-3f0b0c04.js ***!
      \*************************************************************/

    /*! exports provided: c, g, h, o */

    /***/
    function node_modulesIonicCoreDistEsmTheme3f0b0c04Js(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "c", function () {
        return createColorClasses;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "g", function () {
        return getClassMap;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "h", function () {
        return hostContext;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "o", function () {
        return openURL;
      });

      var hostContext = function hostContext(selector, el) {
        return el.closest(selector) !== null;
      };
      /**
       * Create the mode and color classes for the component based on the classes passed in
       */


      var createColorClasses = function createColorClasses(color) {
        return typeof color === 'string' && color.length > 0 ? _defineProperty({
          'ion-color': true
        }, "ion-color-".concat(color), true) : undefined;
      };

      var getClassList = function getClassList(classes) {
        if (classes !== undefined) {
          var array = Array.isArray(classes) ? classes : classes.split(' ');
          return array.filter(function (c) {
            return c != null;
          }).map(function (c) {
            return c.trim();
          }).filter(function (c) {
            return c !== '';
          });
        }

        return [];
      };

      var getClassMap = function getClassMap(classes) {
        var map = {};
        getClassList(classes).forEach(function (c) {
          return map[c] = true;
        });
        return map;
      };

      var SCHEME = /^[a-z][a-z0-9+\-.]*:/;

      var openURL = /*#__PURE__*/function () {
        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(url, ev, direction, animation) {
          var router;
          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  if (!(url != null && url[0] !== '#' && !SCHEME.test(url))) {
                    _context2.next = 5;
                    break;
                  }

                  router = document.querySelector('ion-router');

                  if (!router) {
                    _context2.next = 5;
                    break;
                  }

                  if (ev != null) {
                    ev.preventDefault();
                  }

                  return _context2.abrupt("return", router.push(url, direction, animation));

                case 5:
                  return _context2.abrupt("return", false);

                case 6:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2);
        }));

        return function openURL(_x6, _x7, _x8, _x9) {
          return _ref3.apply(this, arguments);
        };
      }();
      /***/

    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/main/account/register/register.page.html":
    /*!************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/account/register/register.page.html ***!
      \************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppMainAccountRegisterRegisterPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title>register</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form [formGroup]=\"form\">\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <ion-card color=\"light\">\n            <ion-card>\n              <ion-item>\n                <ion-input color=\"success\" type=\"text\" placeholder=\"First Name\" formControlName=\"fname\" ></ion-input>\n              </ion-item>\n                  <ion-item lines=\"none\" *ngIf=\"!form.get('fname').valid && form.get('fname').touched\">\n                    <p class=\"errValid\">\"First Name\" field can not be empty...</p>\n                  </ion-item>\n            </ion-card>\n  \n  \n            <ion-card>\n              <ion-item>\n                <ion-input color=\"success\" type=\"text\" placeholder=\"last Name\" formControlName=\"lname\" ></ion-input>\n              </ion-item>           \n                  <ion-item lines=\"none\" *ngIf=\"!form.get('lname').valid && form.get('lname').touched\">\n                    <p class=\"errValid\">\"Last Name\" field can not be empty...</p>\n                  </ion-item>\n            </ion-card>\n  \n            <ion-card>\n              <ion-item>\n                <ion-input color=\"success\" type=\"text\" placeholder=\"Username\" formControlName=\"uname\" ></ion-input>\n              </ion-item>\n                  <ion-item lines=\"none\" *ngIf=\"!form.get('uname').valid && form.get('uname').touched\">\n                    <p class=\"errValid\">\"Userame\" field can not be empty...</p>\n                  </ion-item>\n            </ion-card>\n            <ion-card>\n              <ion-item>\n                <ion-input color=\"success\" type=\"email\" placeholder=\"Email\" formControlName=\"email\" ></ion-input>\n              </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"!form.get('email').valid && form.get('email').touched\">\n                      <p class=\"errValid\">\"email\" field can not be empty...</p>\n                    </ion-item>\n            </ion-card>\n            <ion-card>\n              <ion-item>\n                <ion-input color=\"success\" type=\"text\" placeholder=\"Phone Number\" formControlName=\"pnum\" ></ion-input>\n              </ion-item>\n                  <ion-item lines=\"none\" *ngIf=\"!form.get('pnum').valid && form.get('pnum').touched\">\n                    <p class=\"errValid\">\"Phone Number\" field can not be empty...</p>\n                  </ion-item>\n            </ion-card>\n            <ion-card>\n              <ion-item>\n                <ion-input color=\"success\" type=\"password\" placeholder=\"password\" formControlName=\"pass\" ></ion-input>\n              </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"!form.get('pass').valid && form.get('pass').touched\">\n                      <p class=\"errValid\">\"Password\" field can not be empty...</p>\n                    </ion-item>\n            </ion-card>\n            <ion-card>\n\n                <ion-button class=\"ion-text-center\" expand=\"block\" color=\"success\" (click)=\"onRegister()\" > Register </ion-button>\n\n            </ion-card>\n          </ion-card>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </form>\n</ion-content>\n";
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/main/category/single-category/single-category.page.html":
    /*!***************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/category/single-category/single-category.page.html ***!
      \***************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppMainCategorySingleCategorySingleCategoryPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title mode=\"ios\">single-category</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid *ngIf=\"isLoading\">\n    <ion-row>\n      <ion-col class=\"ion-text-center\">\n        <ion-spinner name=\"lines\" color=\"primary\"></ion-spinner>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-grid class=\"pd-0\" *ngIf=\"!isLoading\">\n    <ion-row class=\"pd-0\">\n  \n          <!-- <ion-item class=\"two-column\" lines=\"none\" *ngFor=\"let product of products\"> -->\n            <ion-col class=\"ion-margin-bottom\" size=\"6\" *ngFor=\"let product of moreProducts\" >\n              <ion-card *ngIf=\"product.images.length>0\" routerLink=\"/main/tabs/home/{{product.id}}\">\n                <ion-img [src]=\"product.images[0].src \"></ion-img>\n              </ion-card>\n                  <div class=\"ecom-pro-size\">\n                    <ion-label>\n                      <p class=\"ecom-font-black ion-text-left pt-10 slim-text\">{{ product.name }}</p>\n                      <p *ngIf=\"product.regular_price != product.price\" class=\"ion-text-left ion-float-left mr-15 ecom-font-blue\"><del>{{ product.regular_price }} {{currency}}</del></p>\n                      <p class=\"ion-text-left ecom-font-purple\">{{ product.price }} {{currency}}</p>\n                      <!-- <p class=\"ion-text-left\">{{ product.sale_price }} Tk</p> -->\n                    </ion-label>\n                  </div>  \n            </ion-col>\n            <ion-infinite-scroll threshold=\"50px\" (ionInfinite)=\"loadMoreProducts($event)\">\n              <ion-infinite-scroll-content\n                loadingSpinner=\"bubbles\"\n                loadingText=\"Loading more data...\">\n              </ion-infinite-scroll-content>\n            </ion-infinite-scroll>\n          <!-- </ion-item> -->\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/main/account/account.service.ts":
    /*!*************************************************!*\
      !*** ./src/app/main/account/account.service.ts ***!
      \*************************************************/

    /*! exports provided: AccountService */

    /***/
    function srcAppMainAccountAccountServiceTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AccountService", function () {
        return AccountService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _woocommerce_woocommerce_rest_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @woocommerce/woocommerce-rest-api */
      "./node_modules/@woocommerce/woocommerce-rest-api/index.mjs");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common/http */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../../environments/environment */
      "./src/environments/environment.ts"); // Supports ESM


      var AccountService = /*#__PURE__*/function () {
        function AccountService(loadingCtrl, toastCtrl, http, navCtrl) {
          _classCallCheck(this, AccountService);

          this.loadingCtrl = loadingCtrl;
          this.toastCtrl = toastCtrl;
          this.http = http;
          this.navCtrl = navCtrl;
          this.userExists = false;
        }

        _createClass(AccountService, [{
          key: "createUser",
          value: function createUser(form) {
            var _this = this;

            if (!form.valid) {
              console.log();
              return;
            }

            this.loadingCtrl.create({
              keyboardClose: true,
              spinner: "lines",
              message: "Creating Account..."
            }).then(function (loadingEl) {
              loadingEl.present();
              var data = {
                email: form.value.email,
                first_name: form.value.fname,
                last_name: form.value.lname,
                username: form.value.uname,
                password: form.value.pass,
                billing: {
                  first_name: form.value.fname,
                  last_name: form.value.fname,
                  company: "",
                  address_1: "",
                  address_2: "",
                  city: "",
                  state: "",
                  postcode: "",
                  country: "BD",
                  email: form.value.email,
                  phone: form.value.pnum
                },
                shipping: {
                  first_name: form.value.fname,
                  last_name: form.value.fname,
                  company: "",
                  address_1: "",
                  address_2: "",
                  city: "",
                  state: "",
                  postcode: "",
                  country: "BD"
                }
              };
              var WooCommerce = new _woocommerce_woocommerce_rest_api__WEBPACK_IMPORTED_MODULE_3__["default"]({
                url: _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].siteUrl,
                consumerKey: _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].consumerKey,
                consumerSecret: _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].consumerSecret,
                version: 'wc/v3',
                queryStringAuth: true // Force Basic Authentication as query string true and using under HTTPS

              });
              WooCommerce.post("customers", data).then(function (response) {
                console.log(response.data);

                _this.loadingCtrl.dismiss();

                _this.toastCtrl.create({
                  message: "Registered Successfully...",
                  color: "success",
                  position: 'top',
                  duration: 2000
                }).then(function (toastEl) {
                  toastEl.present();
                });
              })["catch"](function (error) {
                console.log(error.response.data);

                _this.loadingCtrl.dismiss();

                _this.toastCtrl.create({
                  message: "User already exists..",
                  color: "danger",
                  position: 'top',
                  duration: 2000
                }).then(function (toastEl) {
                  toastEl.present();
                });
              });
            });
          }
        }, {
          key: "login",
          value: function login(form) {
            var _this2 = this;

            if (this.userExists) {
              this.toastCtrl.create({
                message: "Already logged in as " + this.data.data.displayName,
                color: "warning",
                position: 'top',
                duration: 5000
              }).then(function (toastEl) {
                toastEl.present();
              });
            } else {
              this.loadingCtrl.create({
                message: "logging in...",
                spinner: "lines"
              }).then(function (LoadingEl) {
                LoadingEl.present();

                _this2.http.post('https://woopearl.com/wp-json/jwt-auth/v1/token', {
                  username: form.value.uname,
                  password: form.value.pass
                }).subscribe(function (res) {
                  _this2.loadingCtrl.dismiss();

                  console.log(res);
                  _this2.data = res;
                  console.log(_this2.data.data.email);

                  if (_this2.data.statusCode == 200) {
                    _this2.userExists = true;
                    console.log(_this2.userExists);

                    _this2.navCtrl.navigateForward(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].loggedUrl);

                    _this2.toastCtrl.create({
                      message: "Welcome " + _this2.data.data.displayName + ", login successful...",
                      color: "success",
                      position: 'top',
                      duration: 5000
                    }).then(function (toastEl) {
                      toastEl.present();
                    });
                  } else {
                    _this2.userExists = false;
                    console.log(_this2.userExists);

                    _this2.toastCtrl.create({
                      message: "Invalid Username and Password...",
                      color: "danger",
                      position: 'top',
                      duration: 3000
                    }).then(function (toastEl) {
                      toastEl.present();
                    });
                  }
                });
              });
            }
          }
        }, {
          key: "logOut",
          value: function logOut() {}
        }]);

        return AccountService;
      }();

      AccountService.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
        }, {
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
        }];
      };

      AccountService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], AccountService);
      /***/
    },

    /***/
    "./src/app/main/account/register/register-routing.module.ts":
    /*!******************************************************************!*\
      !*** ./src/app/main/account/register/register-routing.module.ts ***!
      \******************************************************************/

    /*! exports provided: RegisterPageRoutingModule */

    /***/
    function srcAppMainAccountRegisterRegisterRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RegisterPageRoutingModule", function () {
        return RegisterPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _register_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./register.page */
      "./src/app/main/account/register/register.page.ts");

      var routes = [{
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_3__["RegisterPage"]
      }];

      var RegisterPageRoutingModule = function RegisterPageRoutingModule() {
        _classCallCheck(this, RegisterPageRoutingModule);
      };

      RegisterPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], RegisterPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/main/account/register/register.module.ts":
    /*!**********************************************************!*\
      !*** ./src/app/main/account/register/register.module.ts ***!
      \**********************************************************/

    /*! exports provided: RegisterPageModule */

    /***/
    function srcAppMainAccountRegisterRegisterModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RegisterPageModule", function () {
        return RegisterPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _register_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./register-routing.module */
      "./src/app/main/account/register/register-routing.module.ts");
      /* harmony import */


      var _register_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./register.page */
      "./src/app/main/account/register/register.page.ts");

      var RegisterPageModule = function RegisterPageModule() {
        _classCallCheck(this, RegisterPageModule);
      };

      RegisterPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _register_routing_module__WEBPACK_IMPORTED_MODULE_5__["RegisterPageRoutingModule"]],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_6__["RegisterPage"]]
      })], RegisterPageModule);
      /***/
    },

    /***/
    "./src/app/main/account/register/register.page.scss":
    /*!**********************************************************!*\
      !*** ./src/app/main/account/register/register.page.scss ***!
      \**********************************************************/

    /*! exports provided: default */

    /***/
    function srcAppMainAccountRegisterRegisterPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".errValid {\n  font-size: 10px;\n  color: #666;\n  letter-spacing: 0.5px;\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWFpbi9hY2NvdW50L3JlZ2lzdGVyL3JlZ2lzdGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtBQUNKIiwiZmlsZSI6InNyYy9hcHAvbWFpbi9hY2NvdW50L3JlZ2lzdGVyL3JlZ2lzdGVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5lcnJWYWxpZHtcclxuICAgIGZvbnQtc2l6ZToxMHB4O1xyXG4gICAgY29sb3I6ICM2NjY7XHJcbiAgICBsZXR0ZXItc3BhY2luZzogMC41cHg7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/main/account/register/register.page.ts":
    /*!********************************************************!*\
      !*** ./src/app/main/account/register/register.page.ts ***!
      \********************************************************/

    /*! exports provided: RegisterPage */

    /***/
    function srcAppMainAccountRegisterRegisterPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RegisterPage", function () {
        return RegisterPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _account_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../account.service */
      "./src/app/main/account/account.service.ts");

      var RegisterPage = /*#__PURE__*/function () {
        function RegisterPage(accountService) {
          _classCallCheck(this, RegisterPage);

          this.accountService = accountService;
        }

        _createClass(RegisterPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
              fname: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, {
                updateOn: 'blur',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
              }),
              lname: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, {
                updateOn: 'blur',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
              }),
              uname: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, {
                updateOn: 'blur',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
              }),
              email: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, {
                updateOn: 'blur',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
              }),
              pnum: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, {
                updateOn: 'blur',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
              }),
              pass: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, {
                updateOn: 'blur',
                validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
              })
            });
          }
        }, {
          key: "onRegister",
          value: function onRegister() {
            console.log(this.form.value);
            this.accountService.createUser(this.form);
          }
        }]);

        return RegisterPage;
      }();

      RegisterPage.ctorParameters = function () {
        return [{
          type: _account_service__WEBPACK_IMPORTED_MODULE_3__["AccountService"]
        }];
      };

      RegisterPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-register',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./register.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/main/account/register/register.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./register.page.scss */
        "./src/app/main/account/register/register.page.scss"))["default"]]
      })], RegisterPage);
      /***/
    },

    /***/
    "./src/app/main/category/single-category/single-category-routing.module.ts":
    /*!*********************************************************************************!*\
      !*** ./src/app/main/category/single-category/single-category-routing.module.ts ***!
      \*********************************************************************************/

    /*! exports provided: SingleCategoryPageRoutingModule */

    /***/
    function srcAppMainCategorySingleCategorySingleCategoryRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SingleCategoryPageRoutingModule", function () {
        return SingleCategoryPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _single_category_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./single-category.page */
      "./src/app/main/category/single-category/single-category.page.ts");

      var routes = [{
        path: '',
        component: _single_category_page__WEBPACK_IMPORTED_MODULE_3__["SingleCategoryPage"]
      }];

      var SingleCategoryPageRoutingModule = function SingleCategoryPageRoutingModule() {
        _classCallCheck(this, SingleCategoryPageRoutingModule);
      };

      SingleCategoryPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], SingleCategoryPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/main/category/single-category/single-category.module.ts":
    /*!*************************************************************************!*\
      !*** ./src/app/main/category/single-category/single-category.module.ts ***!
      \*************************************************************************/

    /*! exports provided: SingleCategoryPageModule */

    /***/
    function srcAppMainCategorySingleCategorySingleCategoryModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SingleCategoryPageModule", function () {
        return SingleCategoryPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _single_category_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./single-category-routing.module */
      "./src/app/main/category/single-category/single-category-routing.module.ts");
      /* harmony import */


      var _single_category_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./single-category.page */
      "./src/app/main/category/single-category/single-category.page.ts");

      var SingleCategoryPageModule = function SingleCategoryPageModule() {
        _classCallCheck(this, SingleCategoryPageModule);
      };

      SingleCategoryPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _single_category_routing_module__WEBPACK_IMPORTED_MODULE_5__["SingleCategoryPageRoutingModule"]],
        declarations: [_single_category_page__WEBPACK_IMPORTED_MODULE_6__["SingleCategoryPage"]]
      })], SingleCategoryPageModule);
      /***/
    },

    /***/
    "./src/app/main/category/single-category/single-category.page.scss":
    /*!*************************************************************************!*\
      !*** ./src/app/main/category/single-category/single-category.page.scss ***!
      \*************************************************************************/

    /*! exports provided: default */

    /***/
    function srcAppMainCategorySingleCategorySingleCategoryPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21haW4vY2F0ZWdvcnkvc2luZ2xlLWNhdGVnb3J5L3NpbmdsZS1jYXRlZ29yeS5wYWdlLnNjc3MifQ== */";
      /***/
    },

    /***/
    "./src/app/main/category/single-category/single-category.page.ts":
    /*!***********************************************************************!*\
      !*** ./src/app/main/category/single-category/single-category.page.ts ***!
      \***********************************************************************/

    /*! exports provided: SingleCategoryPage */

    /***/
    function srcAppMainCategorySingleCategorySingleCategoryPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SingleCategoryPage", function () {
        return SingleCategoryPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _woocommerce_woocommerce_rest_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @woocommerce/woocommerce-rest-api */
      "./node_modules/@woocommerce/woocommerce-rest-api/index.mjs");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../../../../environments/environment */
      "./src/environments/environment.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

      var SingleCategoryPage = /*#__PURE__*/function () {
        function SingleCategoryPage(activaedRoute) {
          _classCallCheck(this, SingleCategoryPage);

          this.activaedRoute = activaedRoute;
          this.currency = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].currency;
          this.isLoading = false;
          this.isSale = false;
          this.isLoading = true;
          this.page = 2; //this.loadProducts();

          this.loadMoreProducts(null);
          this.loadCategory();
        }

        _createClass(SingleCategoryPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "loadProducts",
          value: function loadProducts() {
            var _this3 = this;

            var WooCommerce = new _woocommerce_woocommerce_rest_api__WEBPACK_IMPORTED_MODULE_2__["default"]({
              url: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].siteUrl,
              consumerKey: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].consumerKey,
              consumerSecret: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].consumerSecret,
              version: 'wc/v3',
              queryStringAuth: true // Force Basic Authentication as query string true and using under HTTPS

            });
            WooCommerce.get("products?per_page=20&orderby=date&order=asc").then(function (response) {
              console.log(response);
              _this3.products = response.data;
            })["catch"](function (error) {
              console.log(error);
            });
          }
        }, {
          key: "loadMoreProducts",
          value: function loadMoreProducts(event) {
            var _this4 = this;

            console.log(event);
            this.activaedRoute.paramMap.subscribe(function (paramMap) {
              _this4.cat_id = paramMap.get("categoryId");
              console.log("cat_id", _this4.cat_id);
              console.log(typeof _this4.cat_id);
              console.log("cat_id_out", _this4.cat_id);
              var WooCommerce = new _woocommerce_woocommerce_rest_api__WEBPACK_IMPORTED_MODULE_2__["default"]({
                url: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].siteUrl,
                consumerKey: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].consumerKey,
                consumerSecret: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].consumerSecret,
                version: 'wc/v3',
                queryStringAuth: true // Force Basic Authentication as query string true and using under HTTPS

              });

              if (event == null) {
                _this4.page = 2;
                _this4.moreProducts = [];
              } else {
                _this4.page = _this4.page + 1;
              }

              WooCommerce.get("products?per_page=6&page=" + _this4.page + "&category=" + _this4.cat_id).then(function (response) {
                console.log(response);
                _this4.moreProducts = _this4.moreProducts.concat(response.data);
                _this4.isLoading = false;

                if (event != null) {
                  event.target.complete();

                  if (response.data.length < 1) {
                    event.target.disabled = true;
                  }
                }
              })["catch"](function (error) {
                console.log(error);
              });
            }); //activated route ends
          }
        }, {
          key: "loadCategory",
          value: function loadCategory() {
            var WooCommerce = new _woocommerce_woocommerce_rest_api__WEBPACK_IMPORTED_MODULE_2__["default"]({
              url: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].siteUrl,
              consumerKey: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].consumerKey,
              consumerSecret: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].consumerSecret,
              version: 'wc/v3',
              queryStringAuth: true // Force Basic Authentication as query string true and using under HTTPS

            });
            WooCommerce.get("products/categories?per_page=9").then(function (response) {
              console.log(response.data);
            })["catch"](function (error) {
              console.log(error.response.data);
            });
          }
        }]);

        return SingleCategoryPage;
      }();

      SingleCategoryPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"]
        }];
      };

      SingleCategoryPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-single-category',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./single-category.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/main/category/single-category/single-category.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./single-category.page.scss */
        "./src/app/main/category/single-category/single-category.page.scss"))["default"]]
      })], SingleCategoryPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=common-es5.js.map