(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["cart-cart-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/main/cart/cart.page.html":
    /*!********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/cart/cart.page.html ***!
      \********************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppMainCartCartPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title mode=\"ios\">Cart</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    <ion-row>\n      <ion-col *ngIf=\"showEmpltyMeaage\">\n        <p class=\"mt-200 ion-text-center\">\n          No cart items yet !!! \n        </p>\n      </ion-col>\n      <ion-col *ngIf=\"!showEmpltyMeaage\">\n        <ion-list>\n          <ion-item *ngFor=\"let item of cartItems; let i = index\" >\n            <ion-thumbnail>\n              <img src=\"{{ item.product.images[0].src }}\" alt=\"\">\n            </ion-thumbnail>\n            <ion-label>\n              <h5 class=\"ecom-pro-qty\">{{ item.product.name }}</h5>\n              <p><span class=\"ecom-pro-qty\">{{ item.qty }}</span>&#215;{{ item.product.price }}</p>\n              <div class=\"ion-float-left\">\n                <ion-button fill=\"clear\" (click)=\"onChangeQuantity(item, i, -1)\"><ion-icon slot=\"icon-only\" color=\"danger\" name=\"remove-circle\"></ion-icon></ion-button>\n                  <span id=\"ecom-input-qty\">{{ item.qty }}</span>\n                <ion-button fill=\"clear\" (click)=\"onChangeQuantity(item, i, 1)\"><ion-icon slot=\"icon-only\" color=\"danger\" name=\"add-circle\"></ion-icon></ion-button>\n              </div>\n              <div class=\"ion-float-right\">\n                <ion-button color=\"light\" slot=\"icon-only\" (click)=\"onRemoveItem(item, i)\"><ion-icon  color=\"danger\" name=\"trash\"></ion-icon></ion-button>\n              </div>\n            </ion-label>\n          </ion-item>\n        </ion-list>\n        <ion-card>\n          <ion-item>\n            <ion-input type=\"text\" [(ngModel)]=\"coupon\" placeholder=\"Enter coupon\"></ion-input>\n            <ion-button color=\"success\" (click)=\"getCoupon()\">Apply</ion-button>\n          </ion-item>\n        </ion-card>\n        <ion-card>\n          <ion-item >\n            <ion-label>\n              <h5 class=\"ion-float-left\">Sub Total</h5>\n              <h5 class=\"ion-float-right\">{{ currency }}.{{ total }}</h5>\n            </ion-label>          \n          </ion-item>\n        </ion-card>      \n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/main/cart/cart-routing.module.ts":
    /*!**************************************************!*\
      !*** ./src/app/main/cart/cart-routing.module.ts ***!
      \**************************************************/

    /*! exports provided: CartPageRoutingModule */

    /***/
    function srcAppMainCartCartRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CartPageRoutingModule", function () {
        return CartPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _cart_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./cart.page */
      "./src/app/main/cart/cart.page.ts");

      var routes = [{
        path: '',
        component: _cart_page__WEBPACK_IMPORTED_MODULE_3__["CartPage"]
      }];

      var CartPageRoutingModule = function CartPageRoutingModule() {
        _classCallCheck(this, CartPageRoutingModule);
      };

      CartPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], CartPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/main/cart/cart.module.ts":
    /*!******************************************!*\
      !*** ./src/app/main/cart/cart.module.ts ***!
      \******************************************/

    /*! exports provided: CartPageModule */

    /***/
    function srcAppMainCartCartModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CartPageModule", function () {
        return CartPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _cart_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./cart-routing.module */
      "./src/app/main/cart/cart-routing.module.ts");
      /* harmony import */


      var _cart_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./cart.page */
      "./src/app/main/cart/cart.page.ts");

      var CartPageModule = function CartPageModule() {
        _classCallCheck(this, CartPageModule);
      };

      CartPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _cart_routing_module__WEBPACK_IMPORTED_MODULE_5__["CartPageRoutingModule"]],
        declarations: [_cart_page__WEBPACK_IMPORTED_MODULE_6__["CartPage"]]
      })], CartPageModule);
      /***/
    },

    /***/
    "./src/app/main/cart/cart.page.scss":
    /*!******************************************!*\
      !*** ./src/app/main/cart/cart.page.scss ***!
      \******************************************/

    /*! exports provided: default */

    /***/
    function srcAppMainCartCartPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".ecom-right {\n  right: 0 !important;\n}\n\n.ecom-full-width {\n  width: 100% !important;\n}\n\n.ecom-full-width #qty {\n  width: 20%;\n}\n\n.ecom-right {\n  right: 10px !important;\n}\n\n#ecom-input-qty {\n  margin: 0 5px;\n  line-height: 2;\n}\n\n.ecom-pro-qty {\n  margin-left: 15px;\n}\n\nion-thumbnail {\n  margin-right: 5px;\n  width: 75px;\n  height: 75px;\n}\n\nion-thumbnail img {\n  border-radius: 5px;\n  box-shadow: 5px 5px 5px #6e6d6d;\n}\n\n.mt-200 {\n  margin-top: 200px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWFpbi9jYXJ0L2NhcnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQUE7QUFDSjs7QUFDQTtFQUNJLHNCQUFBO0FBRUo7O0FBREk7RUFDSSxVQUFBO0FBR1I7O0FBQUE7RUFDSSxzQkFBQTtBQUdKOztBQURBO0VBQ0ksYUFBQTtFQUNBLGNBQUE7QUFJSjs7QUFGQTtFQUNJLGlCQUFBO0FBS0o7O0FBSEE7RUFDSSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBTUo7O0FBTEk7RUFDSSxrQkFBQTtFQUNBLCtCQUFBO0FBT1I7O0FBSkE7RUFDSSxpQkFBQTtBQU9KIiwiZmlsZSI6InNyYy9hcHAvbWFpbi9jYXJ0L2NhcnQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmVjb20tcmlnaHR7XHJcbiAgICByaWdodDowICFpbXBvcnRhbnQ7XHJcbn1cclxuLmVjb20tZnVsbC13aWR0aHtcclxuICAgIHdpZHRoOjEwMCUgIWltcG9ydGFudDtcclxuICAgICNxdHl7XHJcbiAgICAgICAgd2lkdGg6MjAlO1xyXG4gICAgfVxyXG59XHJcbi5lY29tLXJpZ2h0e1xyXG4gICAgcmlnaHQ6MTBweCAhaW1wb3J0YW50O1xyXG59XHJcbiNlY29tLWlucHV0LXF0eXtcclxuICAgIG1hcmdpbjogMCA1cHg7XHJcbiAgICBsaW5lLWhlaWdodDogMjtcclxufVxyXG4uZWNvbS1wcm8tcXR5e1xyXG4gICAgbWFyZ2luLWxlZnQ6IDE1cHg7XHJcbn1cclxuaW9uLXRodW1ibmFpbHtcclxuICAgIG1hcmdpbi1yaWdodDo1cHg7XHJcbiAgICB3aWR0aDo3NXB4O1xyXG4gICAgaGVpZ2h0Ojc1cHg7XHJcbiAgICBpbWd7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgICAgIGJveC1zaGFkb3c6IDVweCA1cHggNXB4ICM2ZTZkNmQ7XHJcbiAgICB9XHJcbn1cclxuLm10LTIwMHtcclxuICAgIG1hcmdpbi10b3A6MjAwcHg7XHJcbn0iXX0= */";
      /***/
    },

    /***/
    "./src/app/main/cart/cart.page.ts":
    /*!****************************************!*\
      !*** ./src/app/main/cart/cart.page.ts ***!
      \****************************************/

    /*! exports provided: CartPage */

    /***/
    function srcAppMainCartCartPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CartPage", function () {
        return CartPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/storage */
      "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
      /* harmony import */


      var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/environments/environment */
      "./src/environments/environment.ts");
      /* harmony import */


      var _woocommerce_woocommerce_rest_api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @woocommerce/woocommerce-rest-api */
      "./node_modules/@woocommerce/woocommerce-rest-api/index.mjs");
      /* harmony import */


      var _home_product_detail_cart_modal_cart_modal_service_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../home/product-detail/cart-modal/cart-modal-service.service */
      "./src/app/main/home/product-detail/cart-modal/cart-modal-service.service.ts"); // Supports ESM


      var CartPage = /*#__PURE__*/function () {
        function CartPage(storage, modalCtrl, loadingCtrl, toastCtrl, cartModalService) {
          _classCallCheck(this, CartPage);

          this.storage = storage;
          this.modalCtrl = modalCtrl;
          this.loadingCtrl = loadingCtrl;
          this.toastCtrl = toastCtrl;
          this.cartModalService = cartModalService;
          this.coupon = "";
          this.currency = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].currency;
          this.cartItems = [];
          this.showEmpltyMeaage = false;
          this.storeCart();
        }

        _createClass(CartPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "getCoupon",
          value: function getCoupon() {
            var _this = this;

            this.storeCart();
            this.loadingCtrl.create({
              keyboardClose: true,
              message: "Applying Coupon...",
              spinner: 'lines'
            }).then(function (loadingEl) {
              loadingEl.present();
            });
            console.log(this.coupon);
            var WooCommerce = new _woocommerce_woocommerce_rest_api__WEBPACK_IMPORTED_MODULE_5__["default"]({
              url: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].siteUrl,
              consumerKey: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].consumerKey,
              consumerSecret: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].consumerSecret,
              version: 'wc/v3',
              queryStringAuth: true // Force Basic Authentication as query string true and using under HTTPS

            });
            WooCommerce.get("coupons?code=" + this.coupon).then(function (response) {
              _this.couponData = response.data; // basic response

              if (response.data.length > 0) {
                // coupon exists             
                var couponedPrice = 0; //apply coupon successfully

                if (response.data[0].discount_type == "fixed_cart") {
                  couponedPrice = parseInt(response.data[0].amount);
                }

                if (response.data[0].discount_type == "percent") {
                  //bug
                  var percent = parseInt(response.data[0].amount) / 100;
                  couponedPrice = _this.total * percent;
                }

                _this.total = _this.total - couponedPrice;
                _this.cartModalService.total = _this.total;
                console.log("service total : ", _this.cartModalService.total);

                _this.loadingCtrl.dismiss();

                _this.toastCtrl.create({
                  message: "Coupon added successfully...",
                  keyboardClose: true,
                  position: "top",
                  duration: 2000,
                  color: "success"
                }).then(function (toastEl) {
                  toastEl.present();
                });
              } else {
                // coupon does not exist
                _this.storeCart();

                _this.loadingCtrl.dismiss();

                _this.toastCtrl.create({
                  message: "Invalid Coupon",
                  keyboardClose: true,
                  position: "top",
                  duration: 2000,
                  color: "danger"
                }).then(function (toastEl) {
                  toastEl.present();
                });
              }
            })["catch"](function (error) {
              console.log(error.response.data);
            });
          }
        }, {
          key: "storeCart",
          value: function storeCart() {
            var _this2 = this;

            this.total = 0;
            this.storage.ready().then(function () {
              _this2.storage.get("cart").then(function (data) {
                console.log(data);
                _this2.cartItems = data;

                if (_this2.cartItems.length > 0) {
                  _this2.cartItems.forEach(function (item, index) {
                    _this2.total = _this2.total + parseInt(item.product.price) * item.qty;
                    _this2.cartModalService.total = _this2.total;
                  });

                  console.log("Total1 :", _this2.total);
                } else {
                  _this2.showEmpltyMeaage = true;
                }
              });
            });
          }
        }, {
          key: "onClosingCartModal",
          value: function onClosingCartModal() {
            this.modalCtrl.dismiss();
          }
        }, {
          key: "onRemoveItem",
          value: function onRemoveItem(item, i) {
            var _this3 = this;

            var qty = item.qty;
            var price = item.product.price;
            this.cartItems.splice(i, 1);
            this.storage.set("cart", this.cartItems).then(function () {
              _this3.total = _this3.total - parseInt(price) * qty;
              _this3.cartModalService.totalCartItems -= qty;
            });
          }
        }, {
          key: "onChangeQuantity",
          value: function onChangeQuantity(item, index, change) {
            var _this4 = this;

            var qty = 0;
            var price = 0;
            qty = item.qty;
            price = parseInt(item.product.price);

            if (change < 0 && item.qty == 1) {
              return;
            } else {
              qty = qty + change;
              item.qty = qty;
              item.price = parseInt(item.product.price) * item.qty;
              this.cartItems[index] = item;
              this.storage.set("cart", this.cartItems).then(function () {
                if (change < 0) {
                  _this4.total = _this4.total - parseInt(item.product.price);
                  _this4.cartModalService.totalCartItems -= 1;
                }

                if (change > 0) {
                  _this4.total = _this4.total + parseInt(item.product.price);
                  _this4.cartModalService.totalCartItems += 1;
                }
              });
            }
          }
        }]);

        return CartPage;
      }();

      CartPage.ctorParameters = function () {
        return [{
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_3__["Storage"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
        }, {
          type: _home_product_detail_cart_modal_cart_modal_service_service__WEBPACK_IMPORTED_MODULE_6__["CartModalServiceService"]
        }];
      };

      CartPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-cart',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./cart.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/main/cart/cart.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./cart.page.scss */
        "./src/app/main/cart/cart.page.scss"))["default"]]
      })], CartPage);
      /***/
    },

    /***/
    "./src/app/main/home/product-detail/cart-modal/cart-modal-service.service.ts":
    /*!***********************************************************************************!*\
      !*** ./src/app/main/home/product-detail/cart-modal/cart-modal-service.service.ts ***!
      \***********************************************************************************/

    /*! exports provided: CartModalServiceService */

    /***/
    function srcAppMainHomeProductDetailCartModalCartModalServiceServiceTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CartModalServiceService", function () {
        return CartModalServiceService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/storage */
      "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");

      var CartModalServiceService = /*#__PURE__*/function () {
        function CartModalServiceService(storage) {
          _classCallCheck(this, CartModalServiceService);

          this.storage = storage;
          this.cartItems = [];
          this.countItems();
        }

        _createClass(CartModalServiceService, [{
          key: "ionViewWillEnter",
          value: function ionViewWillEnter() {
            this.countItems();
          }
        }, {
          key: "countItems",
          value: function countItems() {
            var _this5 = this;

            this.storage.ready().then(function () {
              _this5.storage.get("cart").then(function (data) {
                console.log(data);
                _this5.cartItems = data;
                _this5.totalCartItems = 0;

                if (_this5.cartItems.length > 0) {
                  _this5.cartItems.forEach(function (item, index) {
                    _this5.totalCartItems += item.qty;
                    console.log("cart Item servcie: ", _this5.totalCartItems);
                  });
                }
              });
            });
          }
        }]);

        return CartModalServiceService;
      }();

      CartModalServiceService.ctorParameters = function () {
        return [{
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"]
        }];
      };

      CartModalServiceService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], CartModalServiceService);
      /***/
    }
  }]);
})();
//# sourceMappingURL=cart-cart-module-es5.js.map