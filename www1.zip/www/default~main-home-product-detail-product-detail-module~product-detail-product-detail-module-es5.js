(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~main-home-product-detail-product-detail-module~product-detail-product-detail-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/main/home/product-detail/cart-modal/cart-modal.page.html":
    /*!****************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/home/product-detail/cart-modal/cart-modal.page.html ***!
      \****************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppMainHomeProductDetailCartModalCartModalPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title mode=\"ios\">Cart</ion-title>\n    <ion-buttons slot=\"primary\">\n      <ion-button color=\"danger\" (click)=\"onClosingCartModal()\">\n        <ion-icon slot=\"icon-only\" name=\"close\" ></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    <ion-row>\n      <ion-col *ngIf=\"showEmpltyMeaage\">\n        <p class=\"mt-200 ion-text-center\">\n          No cart items yet !!! \n        </p>\n      </ion-col>\n      <ion-col *ngIf=\"!showEmpltyMeaage\">\n        <ion-list>\n          <ion-item *ngFor=\"let item of cartItems; let i = index\" >\n            <ion-thumbnail>\n              <img src=\"{{ item.product.images[0].src }}\" alt=\"\">\n            </ion-thumbnail>\n            <ion-label>\n              <h5 class=\"ecom-pro-qty\">{{ item.product.name }}</h5>\n              <p><span class=\"ecom-pro-qty\">{{ item.qty }}</span>&#215;{{ item.product.price }}</p>\n              <div class=\"ion-float-left\">\n                <ion-button fill=\"clear\" (click)=\"onChangeQuantity(item, i, -1)\"><ion-icon slot=\"icon-only\" color=\"danger\" name=\"remove-circle\"></ion-icon></ion-button>\n                  <span id=\"ecom-input-qty\">{{ item.qty }}</span>\n                <ion-button fill=\"clear\" (click)=\"onChangeQuantity(item, i, 1)\"><ion-icon slot=\"icon-only\" color=\"danger\" name=\"add-circle\"></ion-icon></ion-button>\n              </div>\n              <div class=\"ion-float-right\">\n                <ion-button color=\"light\" slot=\"icon-only\" (click)=\"onRemoveItem(item, i)\"><ion-icon  color=\"danger\" name=\"trash\"></ion-icon></ion-button>\n              </div>\n            </ion-label>\n          </ion-item>\n        </ion-list>\n        <ion-card>\n          <ion-item>\n            <ion-input type=\"text\" [(ngModel)]=\"coupon\" placeholder=\"Enter coupon\"></ion-input>\n            <ion-button color=\"success\" (click)=\"getCoupon()\">Apply</ion-button>\n          </ion-item>\n        </ion-card>\n        <ion-card>\n          <ion-item >\n            <ion-label>\n              <h5 class=\"ion-float-left\">Sub Total</h5>\n              <h5 class=\"ion-float-right\">{{ currency }}.{{ total }}</h5>\n            </ion-label>          \n          </ion-item>\n        </ion-card>      \n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n\n";
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/main/home/product-detail/product-detail.page.html":
    /*!*********************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/home/product-detail/product-detail.page.html ***!
      \*********************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppMainHomeProductDetailProductDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title mode=\"ios\">product-detail</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-fab edge vertical=\"top\" horizontal=\"end\" slot=\"fixed\" >\n    <ion-fab-button  color=\"danger\" (click)=\"onCartModal()\">\n      <ion-icon name=\"cart\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <!-- <ion-fab *ngIf=\"!isLoading\" vertical=\"top\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button><ion-icon name=\"cart\"></ion-icon></ion-fab-button>\n  </ion-fab> -->\n  <ion-grid *ngIf=\"isLoading\">\n    <ion-row>\n      <ion-col class=\"ion-text-center\">\n        <ion-spinner name=\"lines\" color=\"primary\"></ion-spinner>\n      </ion-col>\n    </ion-row>\n</ion-grid>\n<ion-grid *ngIf=\"!isLoading\">\n  <ion-row>\n    <ion-col>\n      <div class=\"ecom-product\">\n\n        <ion-card>\n          <ion-slides pager=\"true\" [options]=\"slideOpts\" #slider (ionSlidesDidLoad)=\"slidesDidLoad(slider)\">\n            <ion-slide *ngFor=\"let image of product.images\">\n              <img src=\"{{ image.src }}\"/>\n            </ion-slide>\n          </ion-slides>\n        </ion-card>\n        <ion-label class=\"ion-padding\">\n          <!--Category--------------------------start----------------------------->\n          <div *ngFor=\"let category of product.categories\">\n            <ion-badge routerLink=\"/main/tabs/home/category/{{category.id}}\" color=\"light\">{{ category.name }}</ion-badge>\n          </div>\n          <!--Category------------------------------end------------------------->\n          <h2 class=\"ecom-pro-name\">{{ product.name }}</h2>\n          <p *ngIf=\"product.regular_price != product.price\" class=\"ion-text-left ion-float-left mr-15\"><del>{{ product.regular_price }} {{currency}}</del></p>\n          <ion-badge color=\"danger\" class=\"ion-margin-left\">{{ product.price }} {{ currency }}</ion-badge>\n        </ion-label>\n        <div class=\"ecom-buttons\">\n          <ion-button slot=\"start\" color=\"warning\" (click)=\"addToCart()\"><ion-icon name=\"cart\"></ion-icon>Cart</ion-button>\n          <ion-button slot=\"end\" color=\"warning\"><ion-icon name=\"cart\"></ion-icon>Buy Now</ion-button>\n        </div>\n        <div class=\"ecom-toggler-tab\">\n          <ion-button color=\"tertiary\" (click)=\"onShortDescription()\" expand=\"full\">\n            <ion-icon slot=\"start\" name=\"home\"></ion-icon>Descriptions\n          </ion-button>\n          <div class=\"ecom-toggler-invisible\" #slideToggler>\n            <p  [innerHTML]=\"product.description\"></p>\n          </div>\n        </div>\n      </div>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/main/home/product-detail/cart-modal/cart-modal-service.service.ts":
    /*!***********************************************************************************!*\
      !*** ./src/app/main/home/product-detail/cart-modal/cart-modal-service.service.ts ***!
      \***********************************************************************************/

    /*! exports provided: CartModalServiceService */

    /***/
    function srcAppMainHomeProductDetailCartModalCartModalServiceServiceTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CartModalServiceService", function () {
        return CartModalServiceService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/storage */
      "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");

      var CartModalServiceService = /*#__PURE__*/function () {
        function CartModalServiceService(storage) {
          _classCallCheck(this, CartModalServiceService);

          this.storage = storage;
          this.cartItems = [];
          this.countItems();
        }

        _createClass(CartModalServiceService, [{
          key: "ionViewWillEnter",
          value: function ionViewWillEnter() {
            this.countItems();
          }
        }, {
          key: "countItems",
          value: function countItems() {
            var _this = this;

            this.storage.ready().then(function () {
              _this.storage.get("cart").then(function (data) {
                console.log(data);
                _this.cartItems = data;
                _this.totalCartItems = 0;

                if (_this.cartItems.length > 0) {
                  _this.cartItems.forEach(function (item, index) {
                    _this.totalCartItems += item.qty;
                    console.log("cart Item servcie: ", _this.totalCartItems);
                  });
                }
              });
            });
          }
        }]);

        return CartModalServiceService;
      }();

      CartModalServiceService.ctorParameters = function () {
        return [{
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"]
        }];
      };

      CartModalServiceService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], CartModalServiceService);
      /***/
    },

    /***/
    "./src/app/main/home/product-detail/cart-modal/cart-modal.page.scss":
    /*!**************************************************************************!*\
      !*** ./src/app/main/home/product-detail/cart-modal/cart-modal.page.scss ***!
      \**************************************************************************/

    /*! exports provided: default */

    /***/
    function srcAppMainHomeProductDetailCartModalCartModalPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".ecom-right {\n  right: 0 !important;\n}\n\n.ecom-full-width {\n  width: 100% !important;\n}\n\n.ecom-full-width #qty {\n  width: 20%;\n}\n\n.ecom-right {\n  right: 10px !important;\n}\n\n#ecom-input-qty {\n  margin: 0 5px;\n  line-height: 2;\n}\n\n.ecom-pro-qty {\n  margin-left: 15px;\n}\n\nion-thumbnail {\n  margin-right: 5px;\n  width: 75px;\n  height: 75px;\n}\n\nion-thumbnail img {\n  border-radius: 5px;\n  box-shadow: 5px 5px 5px #6e6d6d;\n}\n\n.mt-200 {\n  margin-top: 200px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWFpbi9ob21lL3Byb2R1Y3QtZGV0YWlsL2NhcnQtbW9kYWwvY2FydC1tb2RhbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxtQkFBQTtBQUFKOztBQUVBO0VBQ0ksc0JBQUE7QUFDSjs7QUFBSTtFQUNJLFVBQUE7QUFFUjs7QUFDQTtFQUNJLHNCQUFBO0FBRUo7O0FBQUE7RUFDSSxhQUFBO0VBQ0EsY0FBQTtBQUdKOztBQURBO0VBQ0ksaUJBQUE7QUFJSjs7QUFGQTtFQUNJLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUFLSjs7QUFKSTtFQUNJLGtCQUFBO0VBQ0EsK0JBQUE7QUFNUjs7QUFIQTtFQUNJLGlCQUFBO0FBTUoiLCJmaWxlIjoic3JjL2FwcC9tYWluL2hvbWUvcHJvZHVjdC1kZXRhaWwvY2FydC1tb2RhbC9jYXJ0LW1vZGFsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4uZWNvbS1yaWdodHtcclxuICAgIHJpZ2h0OjAgIWltcG9ydGFudDtcclxufVxyXG4uZWNvbS1mdWxsLXdpZHRoe1xyXG4gICAgd2lkdGg6MTAwJSAhaW1wb3J0YW50O1xyXG4gICAgI3F0eXtcclxuICAgICAgICB3aWR0aDoyMCU7XHJcbiAgICB9XHJcbn1cclxuLmVjb20tcmlnaHR7XHJcbiAgICByaWdodDoxMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuI2Vjb20taW5wdXQtcXR5e1xyXG4gICAgbWFyZ2luOiAwIDVweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyO1xyXG59XHJcbi5lY29tLXByby1xdHl7XHJcbiAgICBtYXJnaW4tbGVmdDogMTVweDtcclxufVxyXG5pb24tdGh1bWJuYWlse1xyXG4gICAgbWFyZ2luLXJpZ2h0OjVweDtcclxuICAgIHdpZHRoOjc1cHg7XHJcbiAgICBoZWlnaHQ6NzVweDtcclxuICAgIGltZ3tcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICAgICAgYm94LXNoYWRvdzogNXB4IDVweCA1cHggIzZlNmQ2ZDtcclxuICAgIH1cclxufVxyXG4ubXQtMjAwe1xyXG4gICAgbWFyZ2luLXRvcDoyMDBweDtcclxufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/main/home/product-detail/cart-modal/cart-modal.page.ts":
    /*!************************************************************************!*\
      !*** ./src/app/main/home/product-detail/cart-modal/cart-modal.page.ts ***!
      \************************************************************************/

    /*! exports provided: CartModalPage */

    /***/
    function srcAppMainHomeProductDetailCartModalCartModalPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CartModalPage", function () {
        return CartModalPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/storage */
      "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../../../../environments/environment */
      "./src/environments/environment.ts");
      /* harmony import */


      var _woocommerce_woocommerce_rest_api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @woocommerce/woocommerce-rest-api */
      "./node_modules/@woocommerce/woocommerce-rest-api/index.mjs");
      /* harmony import */


      var _cart_modal_service_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./cart-modal-service.service */
      "./src/app/main/home/product-detail/cart-modal/cart-modal-service.service.ts"); // Supports ESM


      var CartModalPage = /*#__PURE__*/function () {
        function CartModalPage(storage, modalCtrl, loadingCtrl, toastCtrl, cartModalService) {
          _classCallCheck(this, CartModalPage);

          this.storage = storage;
          this.modalCtrl = modalCtrl;
          this.loadingCtrl = loadingCtrl;
          this.toastCtrl = toastCtrl;
          this.cartModalService = cartModalService;
          this.coupon = "";
          this.currency = _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].currency;
          this.cartItems = [];
          this.showEmpltyMeaage = false;
          this.storeCart();
        }

        _createClass(CartModalPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "getCoupon",
          value: function getCoupon() {
            var _this2 = this;

            this.storeCart();
            this.loadingCtrl.create({
              keyboardClose: true,
              message: "Applying Coupon...",
              spinner: 'lines'
            }).then(function (loadingEl) {
              loadingEl.present();
            });
            console.log(this.coupon);
            var WooCommerce = new _woocommerce_woocommerce_rest_api__WEBPACK_IMPORTED_MODULE_5__["default"]({
              url: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].siteUrl,
              consumerKey: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].consumerKey,
              consumerSecret: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].consumerSecret,
              version: 'wc/v3',
              queryStringAuth: true // Force Basic Authentication as query string true and using under HTTPS

            });
            WooCommerce.get("coupons?code=" + this.coupon).then(function (response) {
              _this2.couponData = response.data; // basic response

              if (response.data.length > 0) {
                // coupon exists             
                var couponedPrice = 0; //apply coupon successfully

                if (response.data[0].discount_type == "fixed_cart") {
                  couponedPrice = parseInt(response.data[0].amount);
                }

                if (response.data[0].discount_type == "percent") {
                  //bug
                  var percent = parseInt(response.data[0].amount) / 100;
                  couponedPrice = _this2.total * percent;
                }

                _this2.total = _this2.total - couponedPrice;
                _this2.cartModalService.total = _this2.total;
                console.log("service total : ", _this2.cartModalService.total);

                _this2.loadingCtrl.dismiss();

                _this2.toastCtrl.create({
                  message: "Coupon added successfully...",
                  keyboardClose: true,
                  position: "top",
                  duration: 2000,
                  color: "success"
                }).then(function (toastEl) {
                  toastEl.present();
                });
              } else {
                // coupon does not exist
                _this2.storeCart();

                _this2.loadingCtrl.dismiss();

                _this2.toastCtrl.create({
                  message: "Invalid Coupon",
                  keyboardClose: true,
                  position: "top",
                  duration: 2000,
                  color: "danger"
                }).then(function (toastEl) {
                  toastEl.present();
                });
              }
            })["catch"](function (error) {
              console.log(error.response.data);
            });
          }
        }, {
          key: "storeCart",
          value: function storeCart() {
            var _this3 = this;

            this.total = 0;
            this.storage.ready().then(function () {
              _this3.storage.get("cart").then(function (data) {
                console.log(data);
                _this3.cartItems = data;
                _this3.cartModalService.totalCartItems = 0;

                if (_this3.cartItems.length > 0) {
                  _this3.cartItems.forEach(function (item, index) {
                    _this3.total = _this3.total + parseInt(item.product.price) * item.qty;
                    _this3.cartModalService.total = _this3.total;
                    _this3.cartModalService.totalCartItems += item.qty;
                    console.log("total item: ", _this3.cartModalService.totalCartItems);
                  });

                  console.log("Total1 :", _this3.total);
                } else {
                  _this3.showEmpltyMeaage = true;
                }
              });
            });
          }
        }, {
          key: "onClosingCartModal",
          value: function onClosingCartModal() {
            this.modalCtrl.dismiss();
          }
        }, {
          key: "onRemoveItem",
          value: function onRemoveItem(item, i) {
            var _this4 = this;

            var qty = item.qty;
            var price = item.product.price;
            this.cartItems.splice(i, 1);
            this.storage.set("cart", this.cartItems).then(function () {
              _this4.total = _this4.total - parseInt(price) * qty;
              _this4.cartModalService.totalCartItems -= qty;
            });
          }
        }, {
          key: "onChangeQuantity",
          value: function onChangeQuantity(item, index, change) {
            var _this5 = this;

            var qty = 0;
            var price = 0;
            qty = item.qty;
            price = parseInt(item.product.price);

            if (change < 0 && item.qty == 1) {
              return;
            } else {
              qty = qty + change;
              item.qty = qty;
              item.price = parseInt(item.product.price) * item.qty;
              this.cartItems[index] = item;
              this.storage.set("cart", this.cartItems).then(function () {
                if (change < 0) {
                  _this5.total = _this5.total - parseInt(item.product.price);
                  _this5.cartModalService.totalCartItems -= 1;
                }

                if (change > 0) {
                  _this5.total = _this5.total + parseInt(item.product.price);
                  _this5.cartModalService.totalCartItems += 1;
                }
              });
            }
          }
        }]);

        return CartModalPage;
      }();

      CartModalPage.ctorParameters = function () {
        return [{
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_3__["Storage"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
        }, {
          type: _cart_modal_service_service__WEBPACK_IMPORTED_MODULE_6__["CartModalServiceService"]
        }];
      };

      CartModalPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-cart-modal',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./cart-modal.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/main/home/product-detail/cart-modal/cart-modal.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./cart-modal.page.scss */
        "./src/app/main/home/product-detail/cart-modal/cart-modal.page.scss"))["default"]]
      })], CartModalPage);
      /***/
    },

    /***/
    "./src/app/main/home/product-detail/product-detail-routing.module.ts":
    /*!***************************************************************************!*\
      !*** ./src/app/main/home/product-detail/product-detail-routing.module.ts ***!
      \***************************************************************************/

    /*! exports provided: ProductDetailPageRoutingModule */

    /***/
    function srcAppMainHomeProductDetailProductDetailRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProductDetailPageRoutingModule", function () {
        return ProductDetailPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _product_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./product-detail.page */
      "./src/app/main/home/product-detail/product-detail.page.ts");

      var routes = [{
        path: '',
        component: _product_detail_page__WEBPACK_IMPORTED_MODULE_3__["ProductDetailPage"]
      }, {
        path: 'cart-modal',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | cart-modal-cart-modal-module */
          "cart-modal-cart-modal-module").then(__webpack_require__.bind(null,
          /*! ./cart-modal/cart-modal.module */
          "./src/app/main/home/product-detail/cart-modal/cart-modal.module.ts")).then(function (m) {
            return m.CartModalPageModule;
          });
        }
      }];

      var ProductDetailPageRoutingModule = function ProductDetailPageRoutingModule() {
        _classCallCheck(this, ProductDetailPageRoutingModule);
      };

      ProductDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], ProductDetailPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/main/home/product-detail/product-detail.module.ts":
    /*!*******************************************************************!*\
      !*** ./src/app/main/home/product-detail/product-detail.module.ts ***!
      \*******************************************************************/

    /*! exports provided: ProductDetailPageModule */

    /***/
    function srcAppMainHomeProductDetailProductDetailModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProductDetailPageModule", function () {
        return ProductDetailPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _product_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./product-detail-routing.module */
      "./src/app/main/home/product-detail/product-detail-routing.module.ts");
      /* harmony import */


      var _product_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./product-detail.page */
      "./src/app/main/home/product-detail/product-detail.page.ts");

      var ProductDetailPageModule = function ProductDetailPageModule() {
        _classCallCheck(this, ProductDetailPageModule);
      };

      ProductDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _product_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProductDetailPageRoutingModule"]],
        declarations: [_product_detail_page__WEBPACK_IMPORTED_MODULE_6__["ProductDetailPage"]]
      })], ProductDetailPageModule);
      /***/
    },

    /***/
    "./src/app/main/home/product-detail/product-detail.page.scss":
    /*!*******************************************************************!*\
      !*** ./src/app/main/home/product-detail/product-detail.page.scss ***!
      \*******************************************************************/

    /*! exports provided: default */

    /***/
    function srcAppMainHomeProductDetailProductDetailPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-card {\n  padding: 0 !important;\n  margin: 0 !important;\n}\n\n.ecom-buttons {\n  width: 100%;\n}\n\n.ecom-buttons ion-button {\n  width: 48% !important;\n}\n\n.ecom-pro-name {\n  color: #2b2727;\n}\n\n.mr-15 {\n  margin-right: 10px;\n}\n\n.ecom-toggler-tab {\n  padding: 10px;\n  transition: 2s !important;\n}\n\n.ecom-toggler-invisible {\n  padding: 10px;\n  transition: 2s !important;\n  display: none;\n}\n\n.ecom-toggler-visible {\n  height: 0%;\n  padding: 10px;\n  border: 1px solid red;\n  transition: 2s !important;\n  display: block !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWFpbi9ob21lL3Byb2R1Y3QtZGV0YWlsL3Byb2R1Y3QtZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLHFCQUFBO0VBQ0Esb0JBQUE7QUFBSjs7QUFFQTtFQUNDLFdBQUE7QUFDRDs7QUFBSTtFQUNJLHFCQUFBO0FBRVI7O0FBRUE7RUFDSSxjQUFBO0FBQ0o7O0FBQ0E7RUFDSSxrQkFBQTtBQUVKOztBQUFBO0VBQ0ksYUFBQTtFQUNBLHlCQUFBO0FBR0o7O0FBREE7RUFDSSxhQUFBO0VBQ0EseUJBQUE7RUFDQSxhQUFBO0FBSUo7O0FBRkE7RUFDSSxVQUFBO0VBQ0EsYUFBQTtFQUNBLHFCQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtBQUtKIiwiZmlsZSI6InNyYy9hcHAvbWFpbi9ob21lL3Byb2R1Y3QtZGV0YWlsL3Byb2R1Y3QtZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5pb24tY2FyZHtcclxuICAgIHBhZGRpbmc6MCAhaW1wb3J0YW50O1xyXG4gICAgbWFyZ2luOjAgIWltcG9ydGFudDtcclxufVxyXG4uZWNvbS1idXR0b25ze1xyXG4gd2lkdGg6IDEwMCU7XHJcbiAgICBpb24tYnV0dG9ue1xyXG4gICAgICAgIHdpZHRoOiA0OCUgIWltcG9ydGFudDtcclxuICAgIH1cclxufVxyXG5cclxuLmVjb20tcHJvLW5hbWV7XHJcbiAgICBjb2xvcjogIzJiMjcyNztcclxufVxyXG4ubXItMTV7XHJcbiAgICBtYXJnaW4tcmlnaHQ6MTBweDtcclxufVxyXG4uZWNvbS10b2dnbGVyLXRhYntcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICB0cmFuc2l0aW9uOiAycyAhaW1wb3J0YW50O1xyXG59XHJcbi5lY29tLXRvZ2dsZXItaW52aXNpYmxle1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIHRyYW5zaXRpb246IDJzICFpbXBvcnRhbnQ7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG59XHJcbi5lY29tLXRvZ2dsZXItdmlzaWJsZXtcclxuICAgIGhlaWdodDogMCU7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgcmVkO1xyXG4gICAgdHJhbnNpdGlvbjogMnMgIWltcG9ydGFudDtcclxuICAgIGRpc3BsYXk6IGJsb2NrICFpbXBvcnRhbnQ7XHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "./src/app/main/home/product-detail/product-detail.page.ts":
    /*!*****************************************************************!*\
      !*** ./src/app/main/home/product-detail/product-detail.page.ts ***!
      \*****************************************************************/

    /*! exports provided: ProductDetailPage */

    /***/
    function srcAppMainHomeProductDetailProductDetailPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProductDetailPage", function () {
        return ProductDetailPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _woocommerce_woocommerce_rest_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @woocommerce/woocommerce-rest-api */
      "./node_modules/@woocommerce/woocommerce-rest-api/index.mjs");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../../../environments/environment */
      "./src/environments/environment.ts");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/storage */
      "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
      /* harmony import */


      var _cart_modal_cart_modal_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./cart-modal/cart-modal.page */
      "./src/app/main/home/product-detail/cart-modal/cart-modal.page.ts"); // Supports ESM
      //import { NavController, NavParams } from '@ionic/angular';


      var ProductDetailPage = /*#__PURE__*/function () {
        function ProductDetailPage( // private navCtrl: NavController,
        //public navParams: NavParams
        activatedRoute, animationCtrl, storage, toastCtrl, navCtrl, modalCtrl) {
          _classCallCheck(this, ProductDetailPage);

          this.activatedRoute = activatedRoute;
          this.animationCtrl = animationCtrl;
          this.storage = storage;
          this.toastCtrl = toastCtrl;
          this.navCtrl = navCtrl;
          this.modalCtrl = modalCtrl;
          this.slideOpts = {
            initialSlide: 0,
            speed: 400
          };
          this.togglerClicked = false;
          this.togglerClicked2 = false;
          this.currency = _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].currency;
          this.isShortDescription = false;
          this.isDescription = false;
          this.isRelatedProduct = false;
          this.isLoading = false; //  this.product = this.navParams.get("productId");
          //  console.log(this.product);

          this.isLoading = true;
        }

        _createClass(ProductDetailPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this6 = this;

            this.activatedRoute.paramMap.subscribe(function (params) {
              //console.log('Params: ', params.productId);
              console.log(params.get('productId'));
              _this6.productId = params.get('productId');
              var WooCommerce = new _woocommerce_woocommerce_rest_api__WEBPACK_IMPORTED_MODULE_2__["default"]({
                url: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].siteUrl,
                consumerKey: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].consumerKey,
                consumerSecret: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].consumerSecret,
                version: 'wc/v3',
                queryStringAuth: true // Force Basic Authentication as query string true and using under HTTPS

              });
              WooCommerce.get("products/" + params.get('productId')).then(function (response) {
                _this6.isLoading = true;
                console.log(response.data);
                _this6.product = response.data;
                _this6.isLoading = false;
              })["catch"](function (error) {
                console.log(error);
              });
              return _this6.product;
            });
          }
        }, {
          key: "slidesDidLoad",
          value: function slidesDidLoad(slides) {
            slides.startAutoplay();
          }
        }, {
          key: "onShortDescription",
          value: function onShortDescription() {
            this.togglerClicked = !this.togglerClicked;

            if (!this.togglerClicked) {
              this.animation = this.animationCtrl.create().addElement(this.slideToggler.nativeElement).duration(1000).fromTo('transform', 'translateX(0)', 'translateX(400px)').fromTo('opacity', '1', '0').afterStyles({
                display: 'none'
              });
            } else {
              this.animation = this.animationCtrl.create().addElement(this.slideToggler.nativeElement).duration(1000).fromTo('transform', 'translateX(400px)', 'translateX(0)').fromTo('opacity', '0', '1').beforeStyles({
                display: 'block',
                color: '#666'
              });
            }

            this.animation.play();
          }
        }, {
          key: "addToCart",
          value: function addToCart() {
            var _this7 = this;

            this.storage.get("cart").then(function (data) {
              if (data == null || data.length == 0) {
                data = [];
                data.push({
                  product: _this7.product,
                  qty: 1,
                  price: parseFloat(_this7.product.price)
                });
                console.log("add to cart first time: ", data);
              } else {
                var added = 0;

                for (var i = 0; i < data.length; i++) {
                  if (data[i].product.id == _this7.product.id) {
                    var qty = data[i].qty;
                    data[i].qty = qty + 1;
                    data[i].price = parseFloat(data[i].price) + parseFloat(data[i].price);
                    added = 1;
                    console.log("add to cart next time: ", data);
                  }
                }

                if (added == 0) {
                  data.push({
                    product: _this7.product,
                    qty: 1,
                    price: _this7.product.price
                  });
                }
              }

              _this7.storage.set("cart", data);

              console.log("all added", data);

              _this7.toastCtrl.create({
                duration: 5000,
                position: "middle",
                color: "tertiary",
                buttons: [{
                  side: 'start',
                  icon: 'star',
                  text: 'View Cart',
                  handler: function handler() {
                    console.log('Favorite clicked');

                    _this7.onCartModal();
                  }
                }, {
                  text: 'not now',
                  role: 'cancel',
                  handler: function handler() {
                    console.log('Cancel clicked');
                  }
                }]
              }).then(function (toast) {
                toast.present();
              });
            });
          }
        }, {
          key: "onCartModal",
          value: function onCartModal() {
            this.modalCtrl.create({
              component: _cart_modal_cart_modal_page__WEBPACK_IMPORTED_MODULE_7__["CartModalPage"],
              swipeToClose: true,
              keyboardClose: true
            }).then(function (modalEl) {
              modalEl.present();
            });
          }
        }]);

        return ProductDetailPage;
      }();

      ProductDetailPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AnimationController"]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"]
        }];
      };

      ProductDetailPage.propDecorators = {
        slideToggler: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
          args: ['slideToggler', {
            "static": false
          }]
        }],
        slideToggler2: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
          args: ['slideToggler', {
            "static": false
          }]
        }],
        cat: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
          args: ['#cat']
        }]
      };
      ProductDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-product-detail',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./product-detail.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/main/home/product-detail/product-detail.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./product-detail.page.scss */
        "./src/app/main/home/product-detail/product-detail.page.scss"))["default"]]
      })], ProductDetailPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=default~main-home-product-detail-product-detail-module~product-detail-product-detail-module-es5.js.map