(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/main/home/home.page.html":
    /*!********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/home/home.page.html ***!
      \********************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppMainHomeHomePageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button menu=\"sidemenu1\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title mode=\"ios\"> Home </ion-title>\n    <ion-button fill=\"clear\" slot=\"end\" routerLink=\"/main/tabs/cart\">\n      <ion-icon class=\"ecom-icon-for-badge\" color=\"dark\" name=\"cart\"></ion-icon>\n      <ion-badge class=\"ecom-cart-badge\" color=\"danger\">{{ totalCartItems }}</ion-badge>\n    </ion-button>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n<!-- <ion-button color=\"primary\" routerLink=\"/main/tabs/home/product-details\">Product</ion-button> -->\n\n  <ion-slides *ngIf=\"!isLoading\" pager=\"true\" #slider (ionSlidesDidLoad)=\"slidesDidLoad(slider)\" [options]=\"slideOpts\">\n    <ion-slide>\n      <img src=\"https://thumbs.dreamstime.com/b/delivery-man-scooter-food-deliveries-courier-delivering-city-bike-route-vector-illustration-meal-logistic-service-driver-151869860.jpg\"/>\n    </ion-slide>\n    <ion-slide>\n      <img src=\"https://static.wixstatic.com/media/86800a_6d442591baaa4a8e9bfc6dc150852c55~mv2.png/v1/fill/w_630,h_352,al_c,q_85,usm_0.66_1.00_0.01/86800a_6d442591baaa4a8e9bfc6dc150852c55~mv2.webp\"/>\n    </ion-slide>\n    <ion-slide>\n      <img src=\"https://image.freepik.com/free-vector/delivery-express-by-parcel-delivery-person-with-scooter-truck-by-e-commerce-system-smartphone-computer-isometric-flat-design-illustration_82984-723.jpg\"/>\n    </ion-slide>\n  </ion-slides>\n\n  <ion-grid *ngIf=\"!isLoading\">\n    <ion-row>\n      <ion-col>\n        <ion-card routerLink=\"/main/tabs/category\">\n          <div class=\"home-icon\">\n            <ion-icon color=\"tertiary\" name=\"american-football\"></ion-icon>\n          </div>\n          <div class=\"home-lab\">\n            <ion-label>Categories</ion-label>\n          </div>\n        </ion-card>\n      </ion-col>\n      <ion-col>\n        <ion-card>\n          <div class=\"home-icon\">\n            <ion-icon color=\"success\" name=\"ellipse\"></ion-icon>\n          </div>\n          <div class=\"home-lab\">\n            <ion-label>Offers</ion-label>\n          </div>\n        </ion-card>\n      </ion-col>\n      <ion-col>\n        <ion-card>\n          <div class=\"home-icon\">\n            <ion-icon color=\"danger\" name=\"headset\"></ion-icon>\n          </div>\n          <div class=\"home-lab\">\n            <ion-label>Products</ion-label>\n          </div>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid *ngIf=\"isLoading\">\n  <ion-row>\n    <ion-col class=\"ion-text-center\">\n      <ion-spinner name=\"lines\" color=\"primary\"></ion-spinner>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n<ion-grid class=\"pd-0\" *ngIf=\"!isLoading\">\n  <ion-row class=\"pd-0\">\n\n        <!-- <ion-item class=\"two-column\" lines=\"none\" *ngFor=\"let product of products\"> -->\n          <ion-col class=\"ion-margin-bottom\" size=\"6\" *ngFor=\"let product of moreProducts\" >\n            <ion-card *ngIf=\"product.images.length>0\" routerLink=\"/main/tabs/home/{{product.id}}\">\n              <ion-img [src]=\"product.images[0].src \"></ion-img>\n            </ion-card>\n                <div class=\"ecom-pro-size\">\n                  <ion-label>\n                    <p class=\"ecom-font-black ion-text-left pt-10 slim-text\">{{ product.name }}</p>\n                    <p *ngIf=\"product.regular_price != product.price\" class=\"ion-text-left ion-float-left mr-15 ecom-font-blue\"><del>{{ product.regular_price }} {{currency}}</del></p>\n                    <p class=\"ion-text-left ecom-font-purple\">{{ product.price }} {{currency}}</p>\n                    <!-- <p class=\"ion-text-left\">{{ product.sale_price }} Tk</p> -->\n                  </ion-label>\n                </div>  \n          </ion-col>\n          <ion-infinite-scroll threshold=\"50px\" (ionInfinite)=\"loadMoreProducts($event)\">\n            <ion-infinite-scroll-content\n              loadingSpinner=\"bubbles\"\n              loadingText=\"Loading more data...\">\n            </ion-infinite-scroll-content>\n          </ion-infinite-scroll>\n        <!-- </ion-item> -->\n  </ion-row>\n</ion-grid>\n<!-- <ion-grid *ngIf=\"!isLoading\">\n  <ion-row>\n    <ion-col>\n      <ion-list *ngFor=\"let productl of moreProducts\">\n        <ion-item detail routerLink=\"/main/tabs/home/{{productl.id}}\">\n          <ion-thumbnail slot=\"start\">\n            <img [src]=\"[productl.images[0].src]\">\n          </ion-thumbnail>\n          <ion-label>\n            <h2>{{ productl.name }}</h2>\n            <p>{{ productl.price }} Tk</p>\n          </ion-label>\n\n        </ion-item>\n      </ion-list>\n      <ion-infinite-scroll threshold=\"50px\" (ionInfinite)=\"loadMoreProducts($event)\">\n        <ion-infinite-scroll-content\n          loadingSpinner=\"bubbles\"\n          loadingText=\"Loading more data...\">\n        </ion-infinite-scroll-content>\n      </ion-infinite-scroll>\n    </ion-col>\n  </ion-row>\n</ion-grid> -->\n<!-- <ion-grid class=\"pd-0\" *ngIf=\"!isLoading\">\n  <ion-row class=\"pd-0\">\n\n         <!--<ion-item class=\"two-column\" lines=\"none\" *ngFor=\"let product of products\"> \n          <ion-col size=\"6\" *ngFor=\"let product of products\" >\n            <ion-card routerLink=\"/main/tabs/home/{{product.id}}\">\n              <ion-img [src]=\"[product.images[0].src]\"></ion-img>\n              <ion-label>{{ product.name }}</ion-label>\n              <ion-card-subtitle>{{ product.price }}</ion-card-subtitle>\n            </ion-card>\n          </ion-col>\n        <!--</ion-item> \n\n  </ion-row>\n</ion-grid> -->\n\n\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/main/home/home-routing.module.ts":
    /*!**************************************************!*\
      !*** ./src/app/main/home/home-routing.module.ts ***!
      \**************************************************/

    /*! exports provided: HomePageRoutingModule */

    /***/
    function srcAppMainHomeHomeRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function () {
        return HomePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./home.page */
      "./src/app/main/home/home.page.ts");

      var routes = [{
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
      }, {
        path: 'product-detail',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | product-detail-product-detail-module */
          "default~main-home-product-detail-product-detail-module~product-detail-product-detail-module").then(__webpack_require__.bind(null,
          /*! ./product-detail/product-detail.module */
          "./src/app/main/home/product-detail/product-detail.module.ts")).then(function (m) {
            return m.ProductDetailPageModule;
          });
        }
      }];

      var HomePageRoutingModule = function HomePageRoutingModule() {
        _classCallCheck(this, HomePageRoutingModule);
      };

      HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], HomePageRoutingModule);
      /***/
    },

    /***/
    "./src/app/main/home/home.module.ts":
    /*!******************************************!*\
      !*** ./src/app/main/home/home.module.ts ***!
      \******************************************/

    /*! exports provided: HomePageModule */

    /***/
    function srcAppMainHomeHomeModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePageModule", function () {
        return HomePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _home_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./home-routing.module */
      "./src/app/main/home/home-routing.module.ts");
      /* harmony import */


      var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./home.page */
      "./src/app/main/home/home.page.ts");

      var HomePageModule = function HomePageModule() {
        _classCallCheck(this, HomePageModule);
      };

      HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _home_routing_module__WEBPACK_IMPORTED_MODULE_5__["HomePageRoutingModule"]],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
      })], HomePageModule);
      /***/
    },

    /***/
    "./src/app/main/home/home.page.scss":
    /*!******************************************!*\
      !*** ./src/app/main/home/home.page.scss ***!
      \******************************************/

    /*! exports provided: default */

    /***/
    function srcAppMainHomeHomePageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-content ion-grid {\n  background: #FCFCFC;\n}\n\n.home-icon {\n  text-align: center;\n  font-size: 20px;\n  padding: 16px 0 8px 0;\n}\n\n.home-lab {\n  text-align: center;\n  padding: 0 0 16px 0;\n}\n\n.two-column {\n  width: 50%;\n  float: left;\n  padding: 0 !important;\n}\n\n.pd-0 {\n  padding: 0 !important;\n}\n\n.pt-10 {\n  padding-top: 10px !important;\n}\n\n.slim-text {\n  font-weight: 200 !important;\n}\n\n.mt {\n  margin: 0;\n}\n\n.mr-15 {\n  margin-right: 15px !important;\n}\n\n.r-0 {\n  position: absolute;\n  right: 0 !important;\n}\n\nion-img {\n  width: 100%;\n  height: 150px;\n}\n\nion-card {\n  padding: 0 !important;\n  margin: 0 !important;\n}\n\n.ecom-font-black {\n  color: #020814;\n  font-size: 15px;\n}\n\n.ecom-font-purple {\n  color: #672dfc;\n  font-size: 15px;\n}\n\n.ecom-font-blue {\n  color: #63A9FC;\n}\n\n.ecom-cart-badge {\n  position: absolute;\n  top: 0;\n  right: 0;\n  border-radius: 50%;\n  z-index: 99999;\n}\n\n.ecom-icon-for-badge {\n  position: relative;\n  right: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWFpbi9ob21lL2hvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNJO0VBQ0ksbUJBQUE7QUFBUjs7QUFHQTtFQUNJLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLHFCQUFBO0FBQUo7O0FBRUE7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0FBQ0o7O0FBRUE7RUFDSSxVQUFBO0VBQ0EsV0FBQTtFQUNBLHFCQUFBO0FBQ0o7O0FBQ0E7RUFDSSxxQkFBQTtBQUVKOztBQUFBO0VBQ0ksNEJBQUE7QUFHSjs7QUFEQTtFQUNJLDJCQUFBO0FBSUo7O0FBRkE7RUFDQyxTQUFBO0FBS0Q7O0FBSEE7RUFDSSw2QkFBQTtBQU1KOztBQUpBO0VBQ0ksa0JBQUE7RUFDQSxtQkFBQTtBQU9KOztBQUxBO0VBQ0ksV0FBQTtFQUNBLGFBQUE7QUFRSjs7QUFOQTtFQUNJLHFCQUFBO0VBQ0Esb0JBQUE7QUFTSjs7QUFOQTtFQUNJLGNBQUE7RUFDQSxlQUFBO0FBU0o7O0FBUEE7RUFDSSxjQUFBO0VBQ0EsZUFBQTtBQVVKOztBQVJBO0VBQ0ksY0FBQTtBQVdKOztBQVRBO0VBQ0ksa0JBQUE7RUFDQSxNQUFBO0VBQ0EsUUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtBQVlKOztBQVZBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0FBYUoiLCJmaWxlIjoic3JjL2FwcC9tYWluL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcclxuICAgIGlvbi1ncmlke1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNGQ0ZDRkM7O1xyXG4gICAgfVxyXG59XHJcbi5ob21lLWljb257XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICBwYWRkaW5nOiAxNnB4IDAgOHB4IDA7XHJcbn1cclxuLmhvbWUtbGFie1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcGFkZGluZzogMCAwIDE2cHggMDtcclxufVxyXG5cclxuLnR3by1jb2x1bW57XHJcbiAgICB3aWR0aDo1MCU7XHJcbiAgICBmbG9hdDpsZWZ0O1xyXG4gICAgcGFkZGluZzowICFpbXBvcnRhbnQ7XHJcbn1cclxuLnBkLTB7XHJcbiAgICBwYWRkaW5nOjAgIWltcG9ydGFudDtcclxufVxyXG4ucHQtMTB7XHJcbiAgICBwYWRkaW5nLXRvcDoxMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuLnNsaW0tdGV4dHtcclxuICAgIGZvbnQtd2VpZ2h0OiAyMDAgIWltcG9ydGFudDtcclxufVxyXG4ubXR7XHJcbiBtYXJnaW46MDtcclxufVxyXG4ubXItMTV7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDE1cHggIWltcG9ydGFudDtcclxufVxyXG4uci0we1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcmlnaHQ6IDAgIWltcG9ydGFudDtcclxufVxyXG5pb24taW1ne1xyXG4gICAgd2lkdGg6MTAwJTtcclxuICAgIGhlaWdodDoxNTBweDtcclxufVxyXG5pb24tY2FyZHtcclxuICAgIHBhZGRpbmc6MCAhaW1wb3J0YW50O1xyXG4gICAgbWFyZ2luOjAgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmVjb20tZm9udC1ibGFja3tcclxuICAgIGNvbG9yOiMwMjA4MTQ7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbn1cclxuLmVjb20tZm9udC1wdXJwbGV7XHJcbiAgICBjb2xvcjogIzY3MmRmYztcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxufVxyXG4uZWNvbS1mb250LWJsdWV7XHJcbiAgICBjb2xvcjogIzYzQTlGQztcclxufVxyXG4uZWNvbS1jYXJ0LWJhZGdle1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICB6LWluZGV4OiA5OTk5OTtcclxufVxyXG4uZWNvbS1pY29uLWZvci1iYWRnZXtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHJpZ2h0OiAxMHB4O1xyXG59XHJcbi8vIC5lY29tLXByby1zaXple1xyXG5cclxuICAgIFxyXG4vLyAgICAgcHtcclxuLy8gICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbi8vICAgICAgICAgYm90dG9tOiAwcHg7XHJcbi8vICAgICAgICAgcmlnaHQ6IDEwcHg7XHJcbi8vICAgICB9XHJcbi8vIH0iXX0= */";
      /***/
    },

    /***/
    "./src/app/main/home/home.page.ts":
    /*!****************************************!*\
      !*** ./src/app/main/home/home.page.ts ***!
      \****************************************/

    /*! exports provided: HomePage */

    /***/
    function srcAppMainHomeHomePageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePage", function () {
        return HomePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _woocommerce_woocommerce_rest_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @woocommerce/woocommerce-rest-api */
      "./node_modules/@woocommerce/woocommerce-rest-api/index.mjs");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../../environments/environment */
      "./src/environments/environment.ts");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/storage */
      "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js"); // Supports ESM
      // import * as WC from 'woocommerce-api'


      var HomePage = /*#__PURE__*/function () {
        function HomePage(loadingCtrl, storage) {
          _classCallCheck(this, HomePage);

          this.loadingCtrl = loadingCtrl;
          this.storage = storage;
          this.slideOpts = {
            initialSlide: 1,
            speed: 500
          };
          this.cartItems = [];
          this.currency = _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].currency;
          this.isLoading = false;
          this.isSale = false;
          this.countItems();
          this.isLoading = true;
          this.page = 2; //this.loadProducts();

          this.loadMoreProducts(null);
          this.loadCategory();
        }

        _createClass(HomePage, [{
          key: "slidesDidLoad",
          value: function slidesDidLoad(slides) {
            slides.startAutoplay();
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {
            this.countItems();
          }
        }, {
          key: "ionViewWillEnter",
          value: function ionViewWillEnter() {
            this.countItems();
          }
        }, {
          key: "loadProducts",
          value: function loadProducts() {
            var _this = this;

            var WooCommerce = new _woocommerce_woocommerce_rest_api__WEBPACK_IMPORTED_MODULE_2__["default"]({
              url: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].siteUrl,
              consumerKey: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].consumerKey,
              consumerSecret: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].consumerSecret,
              version: 'wc/v3',
              queryStringAuth: true // Force Basic Authentication as query string true and using under HTTPS

            });
            WooCommerce.get("products?per_page=20&orderby=date&order=asc").then(function (response) {
              console.log(response);
              _this.products = response.data;
            })["catch"](function (error) {
              console.log(error);
            });
          }
        }, {
          key: "loadMoreProducts",
          value: function loadMoreProducts(event) {
            var _this2 = this;

            console.log(event);
            var WooCommerce = new _woocommerce_woocommerce_rest_api__WEBPACK_IMPORTED_MODULE_2__["default"]({
              url: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].siteUrl,
              consumerKey: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].consumerKey,
              consumerSecret: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].consumerSecret,
              version: 'wc/v3',
              queryStringAuth: true // Force Basic Authentication as query string true and using under HTTPS

            });

            if (event == null) {
              this.page = 2;
              this.moreProducts = [];
            } else {
              this.page = this.page + 1;
            }

            WooCommerce.get("products?per_page=20&page=" + this.page + "&orderby=date&order=desc").then(function (response) {
              console.log(response);
              _this2.moreProducts = _this2.moreProducts.concat(response.data);
              _this2.isLoading = false;

              if (event != null) {
                event.target.complete();

                if (response.data.length < 5) {
                  event.target.disabled = true;
                }
              }
            })["catch"](function (error) {
              console.log(error);
            });
          }
        }, {
          key: "loadCategory",
          value: function loadCategory() {
            var WooCommerce = new _woocommerce_woocommerce_rest_api__WEBPACK_IMPORTED_MODULE_2__["default"]({
              url: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].siteUrl,
              consumerKey: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].consumerKey,
              consumerSecret: _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].consumerSecret,
              version: 'wc/v3',
              queryStringAuth: true // Force Basic Authentication as query string true and using under HTTPS

            });
            WooCommerce.get("products/categories?per_page=9").then(function (response) {
              console.log(response.data);
            })["catch"](function (error) {
              console.log(error.response.data);
            });
          }
        }, {
          key: "countItems",
          value: function countItems() {
            var _this3 = this;

            this.storage.ready().then(function () {
              _this3.storage.get("cart").then(function (data) {
                console.log(data);
                _this3.cartItems = data;
                _this3.totalCartItems = 0;

                if (_this3.cartItems.length > 0) {
                  _this3.cartItems.forEach(function (item, index) {
                    _this3.totalCartItems += item.qty;
                  });
                }
              });
            });
          }
        }]);

        return HomePage;
      }();

      HomePage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"]
        }];
      };

      HomePage.propDecorators = {
        infiniteScroll: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
          args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonInfiniteScroll"]]
        }]
      };
      HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./home.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/main/home/home.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./home.page.scss */
        "./src/app/main/home/home.page.scss"))["default"]]
      })], HomePage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=home-home-module-es5.js.map