(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main-main-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/main/main.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/main.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-tabs>\n  <ion-tab-bar slot=\"bottom\">\n    <ion-tab-button  tab=\"home\">\n      <ion-label>Home</ion-label>\n      <ion-icon color=\"success\" name=\"home\"></ion-icon>\n    </ion-tab-button>\n    <ion-tab-button tab=\"category\">\n      <ion-label>Category</ion-label>\n      <ion-icon color=\"secondary\" name=\"apps\"></ion-icon>\n    </ion-tab-button>\n    <ion-tab-button tab=\"search\">\n      <ion-label>Search</ion-label>\n      <ion-icon color=\"danger\" name=\"search\"></ion-icon>\n    </ion-tab-button>\n    <ion-tab-button tab=\"cart\">\n      <ion-label>Cart</ion-label>\n      <ion-icon color=\"secondary\" name=\"cart\"></ion-icon>\n    </ion-tab-button>\n    <ion-tab-button tab=\"account\">\n      <ion-label>Account</ion-label>\n      <ion-icon color=\"success\" name=\"person\"></ion-icon>\n    </ion-tab-button>\n  </ion-tab-bar>\n</ion-tabs>");

/***/ }),

/***/ "./src/app/main/main-routing.module.ts":
/*!*********************************************!*\
  !*** ./src/app/main/main-routing.module.ts ***!
  \*********************************************/
/*! exports provided: MainPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainPageRoutingModule", function() { return MainPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _main_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./main.page */ "./src/app/main/main.page.ts");




const routes = [
    {
        path: 'tabs',
        component: _main_page__WEBPACK_IMPORTED_MODULE_3__["MainPage"],
        children: [
            {
                path: 'home',
                children: [
                    {
                        path: '',
                        loadChildren: () => Promise.all(/*! import() | home-home-module */[__webpack_require__.e("default~account-account-module~account-register-register-module~cart-cart-module~category-category-m~a63dae00"), __webpack_require__.e("home-home-module")]).then(__webpack_require__.bind(null, /*! ./home/home.module */ "./src/app/main/home/home.module.ts")).then(m => m.HomePageModule)
                    },
                    {
                        path: ':productId',
                        loadChildren: () => Promise.all(/*! import() | main-home-product-detail-product-detail-module */[__webpack_require__.e("default~account-account-module~account-register-register-module~cart-cart-module~category-category-m~a63dae00"), __webpack_require__.e("default~main-home-product-detail-product-detail-module~product-detail-product-detail-module")]).then(__webpack_require__.bind(null, /*! ../main/home/product-detail/product-detail.module */ "./src/app/main/home/product-detail/product-detail.module.ts")).then(m => m.ProductDetailPageModule)
                    }
                ]
            },
            {
                path: 'category',
                children: [
                    {
                        path: '',
                        loadChildren: () => Promise.all(/*! import() | category-category-module */[__webpack_require__.e("default~account-account-module~account-register-register-module~cart-cart-module~category-category-m~a63dae00"), __webpack_require__.e("category-category-module")]).then(__webpack_require__.bind(null, /*! ./category/category.module */ "./src/app/main/category/category.module.ts")).then(m => m.CategoryPageModule)
                    },
                    {
                        path: ':categoryId',
                        loadChildren: () => Promise.all(/*! import() | category-single-category-single-category-module */[__webpack_require__.e("default~account-account-module~account-register-register-module~cart-cart-module~category-category-m~a63dae00"), __webpack_require__.e("common")]).then(__webpack_require__.bind(null, /*! ./category/single-category/single-category.module */ "./src/app/main/category/single-category/single-category.module.ts")).then(m => m.SingleCategoryPageModule)
                    }
                ]
            },
            {
                path: 'search',
                loadChildren: () => Promise.all(/*! import() | search-search-module */[__webpack_require__.e("default~account-account-module~account-register-register-module~cart-cart-module~category-category-m~a63dae00"), __webpack_require__.e("search-search-module")]).then(__webpack_require__.bind(null, /*! ./search/search.module */ "./src/app/main/search/search.module.ts")).then(m => m.SearchPageModule)
            },
            {
                path: 'cart',
                loadChildren: () => Promise.all(/*! import() | cart-cart-module */[__webpack_require__.e("default~account-account-module~account-register-register-module~cart-cart-module~category-category-m~a63dae00"), __webpack_require__.e("cart-cart-module")]).then(__webpack_require__.bind(null, /*! ./cart/cart.module */ "./src/app/main/cart/cart.module.ts")).then(m => m.CartPageModule)
            },
            {
                path: 'account',
                children: [
                    {
                        path: '',
                        loadChildren: () => Promise.all(/*! import() | account-account-module */[__webpack_require__.e("default~account-account-module~account-register-register-module~cart-cart-module~category-category-m~a63dae00"), __webpack_require__.e("common"), __webpack_require__.e("account-account-module")]).then(__webpack_require__.bind(null, /*! ./account/account.module */ "./src/app/main/account/account.module.ts")).then(m => m.AccountPageModule)
                    },
                    {
                        path: 'register',
                        loadChildren: () => Promise.all(/*! import() | account-register-register-module */[__webpack_require__.e("default~account-account-module~account-register-register-module~cart-cart-module~category-category-m~a63dae00"), __webpack_require__.e("common")]).then(__webpack_require__.bind(null, /*! ./account/register/register.module */ "./src/app/main/account/register/register.module.ts")).then(m => m.RegisterPageModule)
                    }
                ]
            }
        ]
    },
    {
        path: '',
        redirectTo: '/main/tabs/home',
        pathMatch: 'full'
    }
];
let MainPageRoutingModule = class MainPageRoutingModule {
};
MainPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MainPageRoutingModule);



/***/ }),

/***/ "./src/app/main/main.module.ts":
/*!*************************************!*\
  !*** ./src/app/main/main.module.ts ***!
  \*************************************/
/*! exports provided: MainPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainPageModule", function() { return MainPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _main_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./main-routing.module */ "./src/app/main/main-routing.module.ts");
/* harmony import */ var _main_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./main.page */ "./src/app/main/main.page.ts");







let MainPageModule = class MainPageModule {
};
MainPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _main_routing_module__WEBPACK_IMPORTED_MODULE_5__["MainPageRoutingModule"]
        ],
        declarations: [_main_page__WEBPACK_IMPORTED_MODULE_6__["MainPage"]]
    })
], MainPageModule);



/***/ }),

/***/ "./src/app/main/main.page.scss":
/*!*************************************!*\
  !*** ./src/app/main/main.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21haW4vbWFpbi5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/main/main.page.ts":
/*!***********************************!*\
  !*** ./src/app/main/main.page.ts ***!
  \***********************************/
/*! exports provided: MainPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainPage", function() { return MainPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let MainPage = class MainPage {
    constructor() { }
    ngOnInit() { }
};
MainPage.ctorParameters = () => [];
MainPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-main',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./main.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/main/main.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./main.page.scss */ "./src/app/main/main.page.scss")).default]
    })
], MainPage);



/***/ })

}]);
//# sourceMappingURL=main-main-module-es2015.js.map